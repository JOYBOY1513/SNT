/**
 * Quantum Mastery Lab - Main Application Controller
 * Initializes 3D Bloch visualizer, Circuit studio, Curriculum reader,
 * Challenges lab, and Quiz arena with unified state synchronization.
 */

document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

function initApp() {
  // 1. Initialize Bloch Sphere
  const bloch = new BlochSphere('bloch-canvas', {
    onStateChange: (state) => {
      updateBlochUI(state);
    }
  });
  window.bloch = bloch;

  // 2. Initialize Circuit UI
  const circuit = new CircuitUI('circuit-grid-wrapper', {
    numQubits: 2,
    numSteps: 8
  });
  window.circuit = circuit;

  // 3. Initialize Challenge Manager
  const challengeManager = new ChallengeManager(circuit);
  window.challengeManager = challengeManager;
  challengeManager.loadChallenge(0);

  // 4. Initialize Quiz Arena
  const quizArena = new QuizArena('quiz-container');
  window.quizArena = quizArena;

  // 5. Initialize Curriculum Reader
  initCurriculum();

  // 6. Connect Bloch UI controls
  initBlochControls();

  // 7. Connect Navigation Tabs
  initTabs();

  // 8. Connect Circuit Toolbar
  initCircuitToolbar();
}

function updateBlochUI(state) {
  const thetaSlider = document.getElementById('bloch-theta-slider');
  const phiSlider = document.getElementById('bloch-phi-slider');
  const thetaVal = document.getElementById('bloch-theta-val');
  const phiVal = document.getElementById('bloch-phi-val');

  if (thetaSlider) thetaSlider.value = state.theta;
  if (phiSlider) phiSlider.value = state.phi;
  if (thetaVal) thetaVal.textContent = `${((state.theta * 180) / Math.PI).toFixed(1)}° (${state.theta.toFixed(2)} rad)`;
  if (phiVal) phiVal.textContent = `${((state.phi * 180) / Math.PI).toFixed(1)}° (${state.phi.toFixed(2)} rad)`;

  // Dirac & Coordinates
  const diracEl = document.getElementById('bloch-dirac-state');
  if (diracEl) {
    const aStr = state.alpha.format(3);
    const bStr = state.beta.format(3);
    diracEl.textContent = `|ψ⟩ = (${aStr})|0⟩ + (${bStr})|1⟩`;
  }

  const coordsEl = document.getElementById('bloch-coords');
  if (coordsEl) {
    coordsEl.textContent = `x = ${state.x.toFixed(3)},  y = ${state.y.toFixed(3)},  z = ${state.z.toFixed(3)}`;
  }

  // Probabilities
  const p0Bar = document.getElementById('bloch-p0-bar');
  const p1Bar = document.getElementById('bloch-p1-bar');
  const p0Val = document.getElementById('bloch-p0-val');
  const p1Val = document.getElementById('bloch-p1-val');

  const p0Pct = (state.prob0 * 100).toFixed(1);
  const p1Pct = (state.prob1 * 100).toFixed(1);

  if (p0Bar) p0Bar.style.width = `${p0Pct}%`;
  if (p1Bar) p1Bar.style.width = `${p1Pct}%`;
  if (p0Val) p0Val.textContent = `${p0Pct}%`;
  if (p1Val) p1Val.textContent = `${p1Pct}%`;
}

function initBlochControls() {
  const thetaSlider = document.getElementById('bloch-theta-slider');
  const phiSlider = document.getElementById('bloch-phi-slider');

  if (thetaSlider) {
    thetaSlider.addEventListener('input', (e) => {
      window.bloch.setAngles(parseFloat(e.target.value), window.bloch.phi, false);
    });
  }
  if (phiSlider) {
    phiSlider.addEventListener('input', (e) => {
      window.bloch.setAngles(window.bloch.theta, parseFloat(e.target.value), false);
    });
  }
}

function initCircuitToolbar() {
  // Gate Selector Buttons
  const gateButtons = document.querySelectorAll('.palette-gate-btn');
  gateButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      gateButtons.forEach(b => b.classList.remove('ring-2', 'ring-cyan-400', 'bg-cyan-500/20'));
      btn.classList.add('ring-2', 'ring-cyan-400', 'bg-cyan-500/20');
      window.circuit.selectedGate = btn.getAttribute('data-gate');
    });
  });

  // Export Code Modal / Box
  const exportQiskitBtn = document.getElementById('btn-export-qiskit');
  const exportQasmBtn = document.getElementById('btn-export-qasm');
  const codeViewer = document.getElementById('code-output-viewer');

  if (exportQiskitBtn && codeViewer) {
    exportQiskitBtn.addEventListener('click', () => {
      const code = window.circuit.exportQiskit();
      codeViewer.textContent = code;
    });
  }

  if (exportQasmBtn && codeViewer) {
    exportQasmBtn.addEventListener('click', () => {
      const qasm = window.circuit.exportQASM();
      codeViewer.textContent = qasm;
    });
  }
}

function initTabs() {
  const tabButtons = document.querySelectorAll('[data-tab-target]');
  const tabPanes = document.querySelectorAll('.tab-content-pane');

  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.getAttribute('data-tab-target');

      // Update button styling
      tabButtons.forEach(b => {
        b.classList.remove('border-cyan-400', 'text-cyan-400', 'bg-slate-800/80');
        b.classList.add('border-transparent', 'text-slate-400');
      });
      btn.classList.add('border-cyan-400', 'text-cyan-400', 'bg-slate-800/80');
      btn.classList.remove('border-transparent', 'text-slate-400');

      // Switch pane
      tabPanes.forEach(p => p.classList.add('hidden'));
      const activePane = document.getElementById(target);
      if (activePane) {
        activePane.classList.remove('hidden');
      }

      // If switching to Bloch, trigger resize for canvas
      if (target === 'tab-bloch' && window.bloch) {
        setTimeout(() => {
          window.bloch.resize();
          window.bloch.render();
        }, 50);
      }
    });
  });
}

function initCurriculum() {
  const listContainer = document.getElementById('curriculum-list');
  const readerContainer = document.getElementById('curriculum-reader');
  if (!listContainer || !readerContainer) return;

  let currentModIndex = 0;

  function renderCurriculumList() {
    listContainer.innerHTML = CURRICULUM_DATA.map((mod, idx) => `
      <div onclick="window.selectLesson(${idx})"
        class="p-3 rounded-xl border cursor-pointer transition-all ${idx === currentModIndex ? 'bg-cyan-950/40 border-cyan-500/50 text-white' : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300'}">
        <div class="flex items-center justify-between text-xs mb-1">
          <span class="font-bold text-cyan-400">${mod.badge}</span>
          <span class="text-[10px] text-slate-500 font-mono">${mod.readTime}</span>
        </div>
        <h4 class="text-xs font-semibold">${mod.title}</h4>
      </div>
    `).join('');
  }

  function renderLesson(idx) {
    currentModIndex = idx;
    const mod = CURRICULUM_DATA[idx];
    renderCurriculumList();

    readerContainer.innerHTML = `
      <div class="space-y-4">
        <div class="border-b border-slate-800 pb-4">
          <div class="flex items-center space-x-2 text-xs font-mono text-cyan-400 mb-1">
            <span>${mod.badge}</span>
            <span>•</span>
            <span>${mod.readTime}</span>
          </div>
          <h2 class="text-xl font-bold text-white">${mod.title}</h2>
          <p class="text-xs text-slate-400 mt-1">${mod.subtitle}</p>
        </div>

        <div class="prose prose-invert max-w-none text-slate-200">
          ${mod.content}
        </div>

        <div class="flex items-center justify-between pt-6 border-t border-slate-800">
          <button onclick="window.selectLesson(${Math.max(0, idx - 1)})" ${idx === 0 ? 'disabled class="opacity-40 cursor-not-allowed"' : 'class="hover:text-cyan-400"'}
            class="px-4 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs font-semibold transition-colors">
            ← Previous Lesson
          </button>
          <span class="text-xs text-slate-500 font-mono">${idx + 1} of ${CURRICULUM_DATA.length}</span>
          <button onclick="window.selectLesson(${Math.min(CURRICULUM_DATA.length - 1, idx + 1)})" ${idx === CURRICULUM_DATA.length - 1 ? 'disabled class="opacity-40 cursor-not-allowed"' : 'class="hover:text-cyan-400"'}
            class="px-4 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs font-semibold transition-colors">
            Next Lesson →
          </button>
        </div>
      </div>
    `;
  }

  window.selectLesson = renderLesson;
  renderLesson(0);
}

// Global copy helper
window.copyToClipboard = function(elementId, btnElement) {
  const el = document.getElementById(elementId);
  if (!el) return;
  navigator.clipboard.writeText(el.textContent).then(() => {
    const originalText = btnElement.innerHTML;
    btnElement.innerHTML = '✓ Copied!';
    btnElement.classList.add('bg-emerald-600', 'text-white');
    setTimeout(() => {
      btnElement.innerHTML = originalText;
      btnElement.classList.remove('bg-emerald-600', 'text-white');
    }, 2000);
  });
};
