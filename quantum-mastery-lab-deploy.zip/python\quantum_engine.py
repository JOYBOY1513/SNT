"""
Quantum Mastery Lab - Python Simulation Engine
A pedagogical NumPy/SciPy quantum statevector simulator for students and engineers.
Covers:
- Dirac statevectors in C^(2^n)
- Unitary gates & tensor products (kron)
- Entanglement calculation via Partial Trace & Von Neumann Entropy
- Bell State CHSH Inequality violation (proving non-locality)
- Grover's Amplitude Amplification search
"""

import numpy as np

# Basis vectors
KET_0 = np.array([1, 0], dtype=complex)
KET_1 = np.array([0, 1], dtype=complex)

# Standard Pauli & Unitary Gates (2x2)
I = np.eye(2, dtype=complex)
X = np.array([[0, 1], [1, 0]], dtype=complex)
Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
Z = np.array([[1, 0], [0, -1]], dtype=complex)
H = (1 / np.sqrt(2)) * np.array([[1, 1], [1, -1]], dtype=complex)
S = np.array([[1, 0], [0, 1j]], dtype=complex)
T = np.array([[1, 0], [0, np.exp(1j * np.pi / 4)]], dtype=complex)

# Two-qubit Gates (4x4)
CNOT_01 = np.array([
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 0, 1],
    [0, 0, 1, 0]
], dtype=complex)

CZ_01 = np.array([
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 1, 0],
    [0, 0, 0, -1]
], dtype=complex)

SWAP = np.array([
    [1, 0, 0, 0],
    [0, 0, 1, 0],
    [0, 1, 0, 0],
    [0, 0, 0, 1]
], dtype=complex)


class QuantumCircuitSim:
    """Multi-qubit statevector simulator using matrix tensor products."""

    def __init__(self, num_qubits=2):
        self.num_qubits = num_qubits
        self.dim = 1 << num_qubits
        self.reset()

    def reset(self, initial_state_idx=0):
        self.state = np.zeros(self.dim, dtype=complex)
        self.state[initial_state_idx] = 1.0

    def apply_1q_gate(self, gate_matrix, target_qubit):
        """Applies a 2x2 gate to target_qubit using tensor products."""
        ops = []
        for q in range(self.num_qubits):
            if q == target_qubit:
                ops.append(gate_matrix)
            else:
                ops.append(I)
        # Tensor product across all wires
        full_op = ops[0]
        for op in ops[1:]:
            full_op = np.kron(full_op, op)
        self.state = full_op @ self.state

    def apply_cnot(self, control_qubit=0, target_qubit=1):
        """Applies CNOT with arbitrary control and target."""
        # Projectors |0><0| and |1><1|
        P0 = np.outer(KET_0, KET_0)
        P1 = np.outer(KET_1, KET_1)

        # Operator 1: If control is 0, target is Identity
        ops0 = [I] * self.num_qubits
        ops0[control_qubit] = P0
        full_op0 = ops0[0]
        for op in ops0[1:]:
            full_op0 = np.kron(full_op0, op)

        # Operator 2: If control is 1, target is X
        ops1 = [I] * self.num_qubits
        ops1[control_qubit] = P1
        ops1[target_qubit] = X
        full_op1 = ops1[0]
        for op in ops1[1:]:
            full_op1 = np.kron(full_op1, op)

        full_cnot = full_op0 + full_op1
        self.state = full_cnot @ self.state

    def get_probabilities(self):
        """Calculates measurement probabilities P_i = |a_i|^2."""
        return np.abs(self.state) ** 2

    def sample(self, shots=1024):
        """Samples classical bitstrings from the statevector."""
        probs = self.get_probabilities()
        indices = np.random.choice(self.dim, size=shots, p=probs)
        counts = {}
        for idx in indices:
            bitstring = format(idx, f"0{self.num_qubits}b")
            counts[bitstring] = counts.get(bitstring, 0) + 1
        return counts

    def get_von_neumann_entropy(self):
        """
        Calculates Entanglement Entropy of Qubit 0 by taking partial trace
        over the remaining qubits: rho_A = Tr_B(|psi><psi|).
        """
        rho = np.outer(self.state, np.conj(self.state))
        # Reshape into tensor (2, 2^(n-1), 2, 2^(n-1))
        rest_dim = 1 << (self.num_qubits - 1)
        rho_tensor = rho.reshape((2, rest_dim, 2, rest_dim))
        # Trace over indices 1 and 3 (the B subsystem)
        rho_A = np.trace(rho_tensor, axis1=1, axis2=3)

        # Eigenvalues of 2x2 reduced density matrix
        eigenvals = np.linalg.eigvalsh(rho_A)
        eigenvals = np.clip(eigenvals, 1e-12, 1.0)
        entropy = -np.sum(eigenvals * np.log2(eigenvals))
        return float(entropy) if abs(entropy) > 1e-6 else 0.0

    def dirac_string(self):
        """Formats state as Dirac bra-ket string."""
        terms = []
        for i, amp in enumerate(self.state):
            if abs(amp) > 1e-4:
                bs = format(i, f"0{self.num_qubits}b")
                terms.append(f"({amp:.3f})|{bs}>")
        return " + ".join(terms) if terms else "0"


def simulate_bell_chsh_test(shots=10000):
    """
    Simulates the CHSH Bell Inequality test.
    Classical local hidden variable theories require |S| <= 2.0.
    Quantum entangled Bell states violate this and achieve S = 2*sqrt(2) approx 2.8284.
    """
    print("=" * 60)
    print("[*] SIMULATING CHSH BELL INEQUALITY TEST")
    print("=" * 60)

    # Angles for detectors A and B:
    # a0 = 0, a1 = pi/4
    # b0 = pi/8, b1 = 3*pi/8
    # Correlation E(a, b) = -cos(a - b) for Singlet state |Psi->
    angles_a = [0, np.pi / 4]
    angles_b = [np.pi / 8, 3 * np.pi / 8]

    # Compute correlation values
    correlations = np.zeros((2, 2))
    for i in range(2):
        for j in range(2):
            theta = angles_a[i] - angles_b[j]
            # Theoretical quantum correlation for Singlet state
            correlations[i, j] = -np.cos(theta)

    # CHSH parameter: S = E(a0, b0) - E(a0, b1) + E(a1, b0) + E(a1, b1)
    S = correlations[0, 0] - correlations[0, 1] + correlations[1, 0] + correlations[1, 1]
    S_abs = abs(S)

    print(f"Detector angles set to optimal Tsirelson configuration.")
    print(f"E(a0, b0) = {correlations[0, 0]:.4f}")
    print(f"E(a0, b1) = {correlations[0, 1]:.4f}")
    print(f"E(a1, b0) = {correlations[1, 0]:.4f}")
    print(f"E(a1, b1) = {correlations[1, 1]:.4f}")
    print(f"\nCalculated CHSH Parameter S = {S_abs:.4f}")
    print(f"Classical Local Realism Limit: |S| <= 2.0000")
    print(f"Quantum Mechanics Prediction:  |S| = 2*sqrt(2) = {2 * np.sqrt(2):.4f}")

    if S_abs > 2.0:
        print("[SUCCESS] VIOLATION CONFIRMED: Nature is fundamentally non-locally entangled!")
    print("=" * 60)


def simulate_grover_search():
    """Simulates 2-qubit Grover's Search for marked state |11>."""
    print("\n" + "=" * 60)
    print("[*] SIMULATING GROVER'S ALGORITHM (2 QUBITS, TARGET = |11>)")
    print("=" * 60)

    sim = QuantumCircuitSim(2)

    # 1. Uniform superposition
    sim.apply_1q_gate(H, 0)
    sim.apply_1q_gate(H, 1)
    print("Step 1 (Uniform Superposition):", sim.dirac_string())
    print("Probabilities before oracle:", sim.get_probabilities())

    # 2. Oracle for |11>: CZ gate flips phase of |11>
    # Apply CZ
    sim.state[3] *= -1  # Phase flip on |11>
    print("Step 2 (After Oracle Phase Flip):", sim.dirac_string())

    # 3. Diffuser (Inversion about mean): H -> X -> CZ -> X -> H
    sim.apply_1q_gate(H, 0)
    sim.apply_1q_gate(H, 1)
    sim.apply_1q_gate(X, 0)
    sim.apply_1q_gate(X, 1)
    sim.state[3] *= -1  # CZ
    sim.apply_1q_gate(X, 0)
    sim.apply_1q_gate(X, 1)
    sim.apply_1q_gate(H, 0)
    sim.apply_1q_gate(H, 1)

    print("Step 3 (After Diffusion Operator):", sim.dirac_string())
    probs = sim.get_probabilities()
    print("Final Probabilities:", probs)
    print(f"P(|11>) = {probs[3] * 100:.1f}% -> 100% SUCCESS PROBABILITY!")
    print("=" * 60)


if __name__ == "__main__":
    # Test Bell State creation
    print("Creating Bell State |Phi+>:")
    sim = QuantumCircuitSim(2)
    sim.apply_1q_gate(H, 0)
    sim.apply_cnot(0, 1)
    print("State:", sim.dirac_string())
    print("Entanglement Entropy:", sim.get_von_neumann_entropy(), "bits (Max = 1.0)")
    print("Sample 1024 shots:", sim.sample(1024))

    # Run CHSH and Grover
    simulate_bell_chsh_test()
    simulate_grover_search()
