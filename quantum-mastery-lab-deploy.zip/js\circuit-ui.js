/**
 * Quantum Mastery Lab - Visual Circuit Builder & Stepper
 * Supports 2-4 qubits, multi-qubit gates, step-by-step statevector simulation,
 * measurement sampling, entanglement diagnostics, and Qiskit/QASM code generation.
 */

class CircuitUI {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    if (!this.container) return;

    this.numQubits = options.numQubits || 2;
    this.numSteps = options.numSteps || 8;
    this.selectedGate = 'H';
    this.currentStep = -1; // -1 means initial state before step 0
    this.isPlaying = false;
    this.playTimer = null;

    // Grid representation: array of columns.
    // Each column is an array of gate operations or null for idle wire.
    // Gate operation: { type: 'H', target: 0, control: null, control2: null }
    this.columns = Array.from({ length: this.numSteps }, () => []);
    this.initialStates = Array(this.numQubits).fill(0); // 0 or 1

    this.engine = new QuantumEngine(this.numQubits);
    this.onStateUpdated = options.onStateUpdated || null;

    this.render();
    this.evaluateCircuit();
  }

  setNumQubits(n) {
    this.numQubits = Math.max(1, Math.min(4, n));
    this.initialStates = Array(this.numQubits).fill(0);
    this.engine.setNumQubits(this.numQubits);
    // Clear gates on qubits out of bounds
    for (let c = 0; c < this.numSteps; c++) {
      this.columns[c] = this.columns[c].filter(g =>
        g.target < this.numQubits &&
        (g.control === null || g.control < this.numQubits) &&
        (g.control2 === null || g.control2 < this.numQubits)
      );
    }
    this.currentStep = -1;
    this.render();
    this.evaluateCircuit();
  }

  clearCircuit() {
    this.columns = Array.from({ length: this.numSteps }, () => []);
    this.currentStep = -1;
    this.render();
    this.evaluateCircuit();
  }

  loadPreset(presetName) {
    this.columns = Array.from({ length: this.numSteps }, () => []);
    this.currentStep = -1;

    if (presetName === 'bell-state') {
      this.setNumQubits(2);
      this.columns[0] = [{ type: 'H', target: 0, control: null }];
      this.columns[1] = [{ type: 'CX', target: 1, control: 0 }];
    } else if (presetName === 'ghz-state') {
      this.setNumQubits(3);
      this.columns[0] = [{ type: 'H', target: 0, control: null }];
      this.columns[1] = [{ type: 'CX', target: 1, control: 0 }];
      this.columns[2] = [{ type: 'CX', target: 2, control: 1 }];
    } else if (presetName === 'superdense') {
      this.setNumQubits(2);
      this.columns[0] = [{ type: 'H', target: 0, control: null }];
      this.columns[1] = [{ type: 'CX', target: 1, control: 0 }];
      this.columns[2] = [{ type: 'Z', target: 0, control: null }]; // Encode '10'
      this.columns[3] = [{ type: 'CX', target: 1, control: 0 }]; // Decode
      this.columns[4] = [{ type: 'H', target: 0, control: null }];
    } else if (presetName === 'teleportation') {
      this.setNumQubits(3);
      // q0 is state to teleport, q1 and q2 are EPR pair
      this.columns[0] = [{ type: 'X', target: 0, control: null }]; // State |1> to teleport
      this.columns[1] = [{ type: 'H', target: 1, control: null }];
      this.columns[2] = [{ type: 'CX', target: 2, control: 1 }]; // EPR pair between q1 and q2
      this.columns[3] = [{ type: 'CX', target: 1, control: 0 }]; // Bell measurement
      this.columns[4] = [{ type: 'H', target: 0, control: null }];
      this.columns[5] = [{ type: 'CX', target: 2, control: 1 }]; // Conditional X correction
      this.columns[6] = [{ type: 'CZ', target: 2, control: 0 }]; // Conditional Z correction
    } else if (presetName === 'grover-2q') {
      this.setNumQubits(2);
      // Target item |11>
      // Step 1: Equal superposition
      this.columns[0] = [
        { type: 'H', target: 0, control: null },
        { type: 'H', target: 1, control: null }
      ];
      // Step 2: Oracle for |11> (CZ flips phase of |11>)
      this.columns[1] = [{ type: 'CZ', target: 1, control: 0 }];
      // Step 3: Diffuser
      this.columns[2] = [
        { type: 'H', target: 0, control: null },
        { type: 'H', target: 1, control: null }
      ];
      this.columns[3] = [
        { type: 'X', target: 0, control: null },
        { type: 'X', target: 1, control: null }
      ];
      this.columns[4] = [{ type: 'CZ', target: 1, control: 0 }];
      this.columns[5] = [
        { type: 'X', target: 0, control: null },
        { type: 'X', target: 1, control: null }
      ];
      this.columns[6] = [
        { type: 'H', target: 0, control: null },
        { type: 'H', target: 1, control: null }
      ];
    }

    this.render();
    this.evaluateCircuit();
  }

  // Evaluate state up to stepIndex (-1 = start, 0..numSteps-1)
  evaluateCircuit(stepLimit = this.currentStep) {
    // Initial state setup
    let initIdx = 0;
    for (let q = 0; q < this.numQubits; q++) {
      if (this.initialStates[q] === 1) {
        initIdx |= 1 << (this.numQubits - 1 - q);
      }
    }
    this.engine.resetState(initIdx);

    const targetStep = stepLimit < 0 ? (this.currentStep < 0 ? this.numSteps - 1 : this.currentStep) : stepLimit;

    // Execute gates column by column
    for (let col = 0; col <= targetStep && col < this.numSteps; col++) {
      const gates = this.columns[col] || [];
      for (let g of gates) {
        this.engine.applyGate(g.type, g.target, g.control, g.control2);
      }
    }

    this.updateDiagnostics();
    if (this.onStateUpdated) {
      this.onStateUpdated({
        state: this.engine.cloneState(),
        entropy: this.engine.getEntanglementEntropy(),
        probs: this.engine.getProbabilities()
      });
    }
  }

  stepForward() {
    if (this.currentStep < this.numSteps - 1) {
      this.currentStep++;
      this.highlightStep();
      this.evaluateCircuit(this.currentStep);
    }
  }

  stepBackward() {
    if (this.currentStep > -1) {
      this.currentStep--;
      this.highlightStep();
      this.evaluateCircuit(this.currentStep);
    }
  }

  togglePlay() {
    if (this.isPlaying) {
      this.stopPlay();
    } else {
      this.isPlaying = true;
      const playBtn = document.getElementById('circuit-play-btn');
      if (playBtn) playBtn.innerHTML = '⏸ Pause';
      if (this.currentStep >= this.numSteps - 1) this.currentStep = -1;

      this.playTimer = setInterval(() => {
        if (this.currentStep < this.numSteps - 1) {
          this.stepForward();
        } else {
          this.stopPlay();
        }
      }, 700);
    }
  }

  stopPlay() {
    this.isPlaying = false;
    clearInterval(this.playTimer);
    const playBtn = document.getElementById('circuit-play-btn');
    if (playBtn) playBtn.innerHTML = '▶ Step Run';
  }

  highlightStep() {
    const colEls = this.container.querySelectorAll('.circuit-col');
    colEls.forEach((el, idx) => {
      if (idx === this.currentStep) {
        el.classList.add('border-cyan-400', 'bg-cyan-500/10');
      } else {
        el.classList.remove('border-cyan-400', 'bg-cyan-500/10');
      }
    });
  }

  // UI Event Handler: Handle slot click
  onSlotClick(qubitIdx, colIdx) {
    const colGates = this.columns[colIdx];
    const existingIndex = colGates.findIndex(g => g.target === qubitIdx || g.control === qubitIdx || g.control2 === qubitIdx);

    if (existingIndex >= 0) {
      // Remove existing gate
      colGates.splice(existingIndex, 1);
    } else {
      // Place gate based on selected gate
      const gateType = this.selectedGate;
      if (['H', 'X', 'Y', 'Z', 'S', 'T'].includes(gateType)) {
        colGates.push({ type: gateType, target: qubitIdx, control: null });
      } else if (gateType === 'CX' || gateType === 'CZ' || gateType === 'SWAP') {
        // Multi-qubit gate: default control is (qubitIdx + 1) % numQubits or 0
        const defaultCtrl = qubitIdx === 0 ? 1 : 0;
        if (this.numQubits > 1) {
          // Check if control wire is free in this column
          const ctrlBusy = colGates.some(g => g.target === defaultCtrl || g.control === defaultCtrl);
          if (!ctrlBusy) {
            colGates.push({ type: gateType, target: qubitIdx, control: defaultCtrl });
          }
        }
      } else if (gateType === 'CCX' && this.numQubits >= 3) {
        const c1 = (qubitIdx + 1) % this.numQubits;
        const c2 = (qubitIdx + 2) % this.numQubits;
        colGates.push({ type: 'CCX', target: qubitIdx, control: c1, control2: c2 });
      }
    }

    this.render();
    this.evaluateCircuit();
  }

  toggleInitialState(qIdx) {
    this.initialStates[qIdx] = 1 - this.initialStates[qIdx];
    this.render();
    this.evaluateCircuit();
  }

  render() {
    if (!this.container) return;

    let html = `
      <div class="circuit-grid-container select-none overflow-x-auto py-2">
        <div class="inline-block min-w-full">
    `;

    // Render wire by wire
    for (let q = 0; q < this.numQubits; q++) {
      html += `
        <div class="flex items-center my-3 relative">
          <!-- Wire label & initial state toggle -->
          <div class="w-24 flex items-center justify-between pr-3 shrink-0">
            <span class="text-xs font-mono font-semibold text-cyan-400">q[${q}]</span>
            <button onclick="window.circuit.toggleInitialState(${q})"
              class="px-2 py-0.5 text-xs font-mono rounded bg-slate-800 border border-slate-700 hover:border-cyan-400 text-slate-200 transition-colors"
              title="Click to toggle initial state between |0⟩ and |1⟩">
              |${this.initialStates[q]}⟩
            </button>
          </div>

          <!-- Horizontal Wire Line -->
          <div class="absolute left-24 right-0 h-0.5 bg-slate-700 -z-0"></div>

          <!-- Step Slots -->
          <div class="flex items-center space-x-2 z-10">
      `;

      for (let c = 0; c < this.numSteps; c++) {
        const colGates = this.columns[c] || [];
        const gate = colGates.find(g => g.target === q);
        const isControl = colGates.find(g => g.control === q || g.control2 === q);

        let slotContent = '';
        let slotStyle = 'border-dashed border-slate-800 hover:border-slate-500 bg-slate-900/40';

        if (gate) {
          slotStyle = 'border-solid border-cyan-500/80 bg-slate-900 shadow-lg shadow-cyan-500/20';
          if (['CX', 'CZ', 'SWAP'].includes(gate.type)) {
            const ctrlText = gate.control !== null ? ` (c:q${gate.control})` : '';
            slotContent = `<span class="font-bold text-xs text-cyan-300">${gate.type}${ctrlText}</span>`;
          } else if (gate.type === 'CCX') {
            slotContent = `<span class="font-bold text-[11px] text-purple-300">CCX</span>`;
          } else {
            slotContent = `<span class="font-bold text-xs text-cyan-200">${gate.type}</span>`;
          }
        } else if (isControl) {
          slotStyle = 'border-solid border-indigo-500/80 bg-indigo-950/60';
          slotContent = `<div class="w-3 h-3 rounded-full bg-indigo-400 shadow-sm shadow-indigo-400"></div>`;
        }

        const isCurrentStep = c === this.currentStep;
        const activeStepBorder = isCurrentStep ? 'ring-2 ring-cyan-400' : '';

        html += `
          <div onclick="window.circuit.onSlotClick(${q}, ${c})"
            class="circuit-slot w-11 h-11 rounded-lg border flex items-center justify-center cursor-pointer transition-all duration-150 ${slotStyle} ${activeStepBorder}"
            title="Step ${c}: Click to place/remove gate">
            ${slotContent}
          </div>
        `;
      }

      html += `
          </div>
        </div>
      `;
    }

    html += `
        </div>
      </div>
    `;

    this.container.innerHTML = html;
  }

  updateDiagnostics() {
    const diracEl = document.getElementById('circuit-dirac-state');
    if (diracEl) {
      diracEl.textContent = this.engine.toDiracString(3);
    }

    const entropyEl = document.getElementById('circuit-entropy-val');
    const entStatusEl = document.getElementById('circuit-entanglement-status');
    const entropy = this.engine.getEntanglementEntropy();

    if (entropyEl) {
      entropyEl.textContent = entropy.toFixed(3);
    }
    if (entStatusEl) {
      if (entropy > 0.05) {
        entStatusEl.className = 'px-2 py-0.5 rounded text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30';
        entStatusEl.textContent = entropy >= 0.95 ? '⚡ Maximally Entangled' : '🔗 Entangled';
      } else {
        entStatusEl.className = 'px-2 py-0.5 rounded text-xs font-semibold bg-slate-800 text-slate-400 border border-slate-700';
        entStatusEl.textContent = '⚪ Separable (Product State)';
      }
    }

    // Render Amplitude Table / Probabilities
    this.renderAmplitudesTable();
  }

  renderAmplitudesTable() {
    const tableContainer = document.getElementById('circuit-state-table');
    if (!tableContainer) return;

    const probs = this.engine.getProbabilities();
    const dim = 1 << this.numQubits;
    let html = `
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
    `;

    for (let i = 0; i < dim; i++) {
      const bitstring = i.toString(2).padStart(this.numQubits, '0');
      const amp = this.engine.state[i];
      const prob = probs[i];
      const probPercent = (prob * 100).toFixed(1);
      const phaseRad = amp.phase();
      const phaseDeg = Math.round((phaseRad * 180) / Math.PI);

      // Color based on complex phase (hue 0 to 360)
      const hue = (phaseDeg + 360) % 360;
      const phaseColor = prob > 0.001 ? `hsl(${hue}, 85%, 65%)` : '#64748b';

      html += `
        <div class="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800/80 flex flex-col justify-between">
          <div class="flex items-center justify-between">
            <span class="font-mono text-xs font-bold text-cyan-300">|${bitstring}⟩</span>
            <div class="flex items-center space-x-1.5">
              <!-- Phase Clock Circle -->
              <div class="w-3.5 h-3.5 rounded-full border border-slate-600 relative flex items-center justify-center" title="Phase: ${phaseDeg}°">
                <div class="w-1.5 h-0.5 absolute left-1/2 origin-left" style="background-color: ${phaseColor}; transform: rotate(${phaseDeg}deg);"></div>
              </div>
              <span class="text-[11px] font-mono text-slate-400">${probPercent}%</span>
            </div>
          </div>
          <!-- Probability Bar -->
          <div class="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
            <div class="h-full rounded-full transition-all duration-300" style="width: ${probPercent}%; background-color: ${phaseColor};"></div>
          </div>
          <div class="text-[10px] font-mono text-slate-500 mt-1 truncate" title="${amp.format(3)}">
            ${amp.format(2)}
          </div>
        </div>
      `;
    }

    html += `</div>`;
    tableContainer.innerHTML = html;
  }

  runSampling(shots = 1024) {
    const counts = this.engine.sample(shots);
    const histContainer = document.getElementById('circuit-histogram');
    if (!histContainer) return;

    let html = `
      <div class="space-y-2 mt-2">
    `;

    const sortedKeys = Object.keys(counts).sort();
    for (let k of sortedKeys) {
      const c = counts[k];
      const pct = ((c / shots) * 100).toFixed(1);
      html += `
        <div>
          <div class="flex justify-between text-xs font-mono text-slate-300 mb-0.5">
            <span class="font-bold text-cyan-400">|${k}⟩</span>
            <span>${c} shots (${pct}%)</span>
          </div>
          <div class="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
            <div class="h-full bg-gradient-to-r from-cyan-500 to-indigo-500 rounded-full transition-all duration-500" style="width: ${pct}%;"></div>
          </div>
        </div>
      `;
    }

    html += `</div>`;
    histContainer.innerHTML = html;
  }

  // Export to Qiskit 1.0+ code
  exportQiskit() {
    let code = `from qiskit import QuantumCircuit, transpile\nfrom qiskit_aer import AerSimulator\n\n`;
    code += `# Initialize quantum circuit with ${this.numQubits} qubits\n`;
    code += `qc = QuantumCircuit(${this.numQubits}, ${this.numQubits})\n\n`;

    // Initial states
    for (let q = 0; q < this.numQubits; q++) {
      if (this.initialStates[q] === 1) {
        code += `qc.x(${q})  # Initialize q[${q}] to |1⟩\n`;
      }
    }

    // Gates
    for (let col = 0; col < this.numSteps; col++) {
      const gates = this.columns[col] || [];
      for (let g of gates) {
        const type = g.type.toLowerCase();
        if (type === 'h') code += `qc.h(${g.target})\n`;
        else if (type === 'x') code += `qc.x(${g.target})\n`;
        else if (type === 'y') code += `qc.y(${g.target})\n`;
        else if (type === 'z') code += `qc.z(${g.target})\n`;
        else if (type === 's') code += `qc.s(${g.target})\n`;
        else if (type === 't') code += `qc.t(${g.target})\n`;
        else if (type === 'cx') code += `qc.cx(${g.control}, ${g.target})\n`;
        else if (type === 'cz') code += `qc.cz(${g.control}, ${g.target})\n`;
        else if (type === 'swap') code += `qc.swap(${g.control}, ${g.target})\n`;
        else if (type === 'ccx') code += `qc.ccx(${g.control}, ${g.control2}, ${g.target})\n`;
      }
    }

    code += `\n# Measurement\nqc.measure(range(${this.numQubits}), range(${this.numQubits}))\n\n`;
    code += `# Execute on local Aer Simulator\nsim = AerSimulator()\ncompiled_circuit = transpile(qc, sim)\njob = sim.run(compiled_circuit, shots=1024)\nresult = job.result()\nprint("Counts:", result.get_counts())\n`;

    return code;
  }

  // Export to OpenQASM 2.0
  exportQASM() {
    let qasm = `OPENQASM 2.0;\ninclude "qelib1.inc";\n\nqreg q[${this.numQubits}];\ncreg c[${this.numQubits}];\n\n`;
    for (let q = 0; q < this.numQubits; q++) {
      if (this.initialStates[q] === 1) qasm += `x q[${q}];\n`;
    }
    for (let col = 0; col < this.numSteps; col++) {
      const gates = this.columns[col] || [];
      for (let g of gates) {
        const type = g.type.toLowerCase();
        if (type === 'cx') qasm += `cx q[${g.control}], q[${g.target}];\n`;
        else if (type === 'cz') qasm += `cz q[${g.control}], q[${g.target}];\n`;
        else if (type === 'swap') {
          qasm += `cx q[${g.control}], q[${g.target}];\n`;
          qasm += `cx q[${g.target}], q[${g.control}];\n`;
          qasm += `cx q[${g.control}], q[${g.target}];\n`;
        } else if (type === 'ccx') {
          qasm += `ccx q[${g.control}], q[${g.control2}], q[${g.target}];\n`;
        } else {
          qasm += `${type} q[${g.target}];\n`;
        }
      }
    }
    qasm += `measure q -> c;\n`;
    return qasm;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = CircuitUI;
}
