/**
 * Quantum Mastery Lab - Core Quantum State & Circuit Simulator
 * Handles statevectors, unitary transformations, entanglement entropy, and sampling.
 */

class QuantumEngine {
  constructor(numQubits = 2) {
    this.numQubits = Math.max(1, Math.min(4, numQubits));
    this.resetState();
  }

  setNumQubits(n) {
    this.numQubits = Math.max(1, Math.min(4, n));
    this.resetState();
  }

  resetState(initialBasis = 0) {
    const dim = 1 << this.numQubits;
    this.state = new Array(dim).fill(null).map(() => Complex.ZERO);
    const initIdx = Math.max(0, Math.min(dim - 1, initialBasis));
    this.state[initIdx] = Complex.ONE;
    return this.state;
  }

  setState(stateVector) {
    const dim = 1 << this.numQubits;
    if (stateVector.length !== dim) {
      throw new Error(`Statevector length ${stateVector.length} does not match 2^${this.numQubits} = ${dim}`);
    }
    this.state = stateVector.map(c => Complex.ensure(c));
    this.normalize();
    return this.state;
  }

  normalize() {
    let normSq = 0;
    for (let i = 0; i < this.state.length; i++) {
      normSq += this.state[i].absSq();
    }
    if (normSq > 1e-12) {
      const invNorm = 1 / Math.sqrt(normSq);
      for (let i = 0; i < this.state.length; i++) {
        this.state[i] = this.state[i].scale(invNorm);
      }
    }
  }

  cloneState() {
    return this.state.map(c => new Complex(c.re, c.im));
  }

  // Single-qubit Unitary Gate Application
  apply1QGate(matrix, targetQubit) {
    const n = this.numQubits;
    const dim = 1 << n;
    const targetMask = 1 << (n - 1 - targetQubit);
    const nextState = new Array(dim).fill(null);

    const u00 = Complex.ensure(matrix[0][0]);
    const u01 = Complex.ensure(matrix[0][1]);
    const u10 = Complex.ensure(matrix[1][0]);
    const u11 = Complex.ensure(matrix[1][1]);

    for (let i = 0; i < dim; i++) {
      if ((i & targetMask) === 0) {
        const i0 = i;
        const i1 = i | targetMask;
        const a0 = this.state[i0];
        const a1 = this.state[i1];

        nextState[i0] = u00.mul(a0).add(u01.mul(a1));
        nextState[i1] = u10.mul(a0).add(u11.mul(a1));
      }
    }

    this.state = nextState;
  }

  // Controlled-1Q Gate Application
  applyControlled1QGate(matrix, controlQubit, targetQubit) {
    const n = this.numQubits;
    const dim = 1 << n;
    const controlMask = 1 << (n - 1 - controlQubit);
    const targetMask = 1 << (n - 1 - targetQubit);
    const nextState = [...this.state];

    const u00 = Complex.ensure(matrix[0][0]);
    const u01 = Complex.ensure(matrix[0][1]);
    const u10 = Complex.ensure(matrix[1][0]);
    const u11 = Complex.ensure(matrix[1][1]);

    for (let i = 0; i < dim; i++) {
      if ((i & controlMask) !== 0 && (i & targetMask) === 0) {
        const i0 = i;
        const i1 = i | targetMask;
        const a0 = this.state[i0];
        const a1 = this.state[i1];

        nextState[i0] = u00.mul(a0).add(u01.mul(a1));
        nextState[i1] = u10.mul(a0).add(u11.mul(a1));
      }
    }

    this.state = nextState;
  }

  // Toffoli (CCX) Gate Application
  applyCCX(c1Qubit, c2Qubit, targetQubit) {
    const n = this.numQubits;
    const dim = 1 << n;
    const c1Mask = 1 << (n - 1 - c1Qubit);
    const c2Mask = 1 << (n - 1 - c2Qubit);
    const tMask = 1 << (n - 1 - targetQubit);
    const nextState = [...this.state];

    for (let i = 0; i < dim; i++) {
      if ((i & c1Mask) !== 0 && (i & c2Mask) !== 0 && (i & tMask) === 0) {
        const i0 = i;
        const i1 = i | tMask;
        const temp = nextState[i0];
        nextState[i0] = nextState[i1];
        nextState[i1] = temp;
      }
    }
    this.state = nextState;
  }

  // SWAP Gate Application
  applySWAP(q1, q2) {
    const n = this.numQubits;
    const dim = 1 << n;
    const m1 = 1 << (n - 1 - q1);
    const m2 = 1 << (n - 1 - q2);
    const nextState = [...this.state];

    for (let i = 0; i < dim; i++) {
      const b1 = (i & m1) !== 0;
      const b2 = (i & m2) !== 0;
      if (b1 !== b2 && !b2) {
        // b1 is 1, b2 is 0 -> swap with partner where b1 is 0, b2 is 1
        const swappedIdx = (i ^ m1) | m2;
        const temp = nextState[i];
        nextState[i] = nextState[swappedIdx];
        nextState[swappedIdx] = temp;
      }
    }
    this.state = nextState;
  }

  // Standard Gates Library
  static GATES = {
    I: [
      [Complex.ONE, Complex.ZERO],
      [Complex.ZERO, Complex.ONE]
    ],
    X: [
      [Complex.ZERO, Complex.ONE],
      [Complex.ONE, Complex.ZERO]
    ],
    Y: [
      [Complex.ZERO, Complex.MINUS_I],
      [Complex.I, Complex.ZERO]
    ],
    Z: [
      [Complex.ONE, Complex.ZERO],
      [Complex.ZERO, new Complex(-1, 0)]
    ],
    H: [
      [new Complex(1 / Math.SQRT2, 0), new Complex(1 / Math.SQRT2, 0)],
      [new Complex(1 / Math.SQRT2, 0), new Complex(-1 / Math.SQRT2, 0)]
    ],
    S: [
      [Complex.ONE, Complex.ZERO],
      [Complex.ZERO, Complex.I]
    ],
    SDG: [
      [Complex.ONE, Complex.ZERO],
      [Complex.ZERO, Complex.MINUS_I]
    ],
    T: [
      [Complex.ONE, Complex.ZERO],
      [Complex.ZERO, new Complex(Math.cos(Math.PI / 4), Math.sin(Math.PI / 4))]
    ],
    TDG: [
      [Complex.ONE, Complex.ZERO],
      [Complex.ZERO, new Complex(Math.cos(Math.PI / 4), -Math.sin(Math.PI / 4))]
    ],
    RX: (theta) => [
      [new Complex(Math.cos(theta / 2), 0), new Complex(0, -Math.sin(theta / 2))],
      [new Complex(0, -Math.sin(theta / 2)), new Complex(Math.cos(theta / 2), 0)]
    ],
    RY: (theta) => [
      [new Complex(Math.cos(theta / 2), 0), new Complex(-Math.sin(theta / 2), 0)],
      [new Complex(Math.sin(theta / 2), 0), new Complex(Math.cos(theta / 2), 0)]
    ],
    RZ: (theta) => [
      [new Complex(Math.cos(-theta / 2), Math.sin(-theta / 2)), Complex.ZERO],
      [Complex.ZERO, new Complex(Math.cos(theta / 2), Math.sin(theta / 2))]
    ]
  };

  applyGate(gateType, target, control = null, control2 = null, param = null) {
    const g = gateType.toUpperCase();
    if (g === 'X') this.apply1QGate(QuantumEngine.GATES.X, target);
    else if (g === 'Y') this.apply1QGate(QuantumEngine.GATES.Y, target);
    else if (g === 'Z') this.apply1QGate(QuantumEngine.GATES.Z, target);
    else if (g === 'H') this.apply1QGate(QuantumEngine.GATES.H, target);
    else if (g === 'S') this.apply1QGate(QuantumEngine.GATES.S, target);
    else if (g === 'SDG') this.apply1QGate(QuantumEngine.GATES.SDG, target);
    else if (g === 'T') this.apply1QGate(QuantumEngine.GATES.T, target);
    else if (g === 'TDG') this.apply1QGate(QuantumEngine.GATES.TDG, target);
    else if (g === 'RX') this.apply1QGate(QuantumEngine.GATES.RX(param ?? Math.PI / 2), target);
    else if (g === 'RY') this.apply1QGate(QuantumEngine.GATES.RY(param ?? Math.PI / 2), target);
    else if (g === 'RZ') this.apply1QGate(QuantumEngine.GATES.RZ(param ?? Math.PI / 2), target);
    else if (g === 'CX' || g === 'CNOT') {
      if (control !== null && control !== target) {
        this.applyControlled1QGate(QuantumEngine.GATES.X, control, target);
      }
    } else if (g === 'CZ') {
      if (control !== null && control !== target) {
        this.applyControlled1QGate(QuantumEngine.GATES.Z, control, target);
      }
    } else if (g === 'SWAP') {
      if (control !== null && control !== target) {
        this.applySWAP(control, target);
      }
    } else if (g === 'CCX' || g === 'TOFFOLI') {
      if (control !== null && control2 !== null && control !== target && control2 !== target && control !== control2) {
        this.applyCCX(control, control2, target);
      }
    }
    this.normalize();
  }

  // Get Probabilities
  getProbabilities() {
    return this.state.map(c => c.absSq());
  }

  // Sample measurements (shots)
  sample(shots = 1024) {
    const probs = this.getProbabilities();
    const counts = {};
    const dim = 1 << this.numQubits;
    for (let i = 0; i < dim; i++) {
      const bitstring = i.toString(2).padStart(this.numQubits, '0');
      counts[bitstring] = 0;
    }

    // Cumulative distribution
    const cumulative = [];
    let sum = 0;
    for (let p of probs) {
      sum += p;
      cumulative.push(sum);
    }

    for (let s = 0; s < shots; s++) {
      const r = Math.random();
      let chosen = 0;
      for (let i = 0; i < cumulative.length; i++) {
        if (r <= cumulative[i]) {
          chosen = i;
          break;
        }
      }
      const bs = chosen.toString(2).padStart(this.numQubits, '0');
      counts[bs] = (counts[bs] || 0) + 1;
    }

    return counts;
  }

  // Reduced density matrix of Qubit 0 (Tracing out the rest)
  // Used to compute Von Neumann Entanglement Entropy
  getEntanglementEntropy() {
    if (this.numQubits < 2) return 0;

    // Density matrix element rho_A[0][0] = sum_{b} |psi(0, b)|^2
    // rho_A[1][1] = sum_{b} |psi(1, b)|^2
    // rho_A[0][1] = sum_{b} psi(0, b) * conj(psi(1, b))
    const n = this.numQubits;
    const restDim = 1 << (n - 1);
    let rho00 = 0;
    let rho11 = 0;
    let rho01 = Complex.ZERO;

    for (let b = 0; b < restDim; b++) {
      const idx0 = b; // Qubit 0 is 0
      const idx1 = b | (1 << (n - 1)); // Qubit 0 is 1

      const a0 = this.state[idx0];
      const a1 = this.state[idx1];

      rho00 += a0.absSq();
      rho11 += a1.absSq();
      rho01 = rho01.add(a0.mul(a1.conj()));
    }

    // Eigenvalues of 2x2 Hermitian matrix:
    // Trace = 1, Det = rho00 * rho11 - |rho01|^2
    // lambda = (1 +- sqrt(1 - 4 * Det)) / 2
    const det = rho00 * rho11 - rho01.absSq();
    const discriminant = Math.max(0, 1 - 4 * det);
    const sqrtDisc = Math.sqrt(discriminant);
    const lambda1 = Math.max(0, Math.min(1, (1 + sqrtDisc) / 2));
    const lambda2 = Math.max(0, Math.min(1, (1 - sqrtDisc) / 2));

    let entropy = 0;
    if (lambda1 > 1e-9) entropy -= lambda1 * Math.log2(lambda1);
    if (lambda2 > 1e-9) entropy -= lambda2 * Math.log2(lambda2);

    return Math.abs(entropy) < 1e-6 ? 0 : entropy;
  }

  // Quantum State Fidelity: F = |<psi|phi>|^2
  static fidelity(stateA, stateB) {
    if (stateA.length !== stateB.length) return 0;
    let innerProd = Complex.ZERO;
    for (let i = 0; i < stateA.length; i++) {
      innerProd = innerProd.add(stateA[i].conj().mul(stateB[i]));
    }
    return innerProd.absSq();
  }

  // Get Dirac Notation String
  toDiracString(precision = 3) {
    const terms = [];
    for (let i = 0; i < this.state.length; i++) {
      const c = this.state[i];
      if (c.absSq() > 1e-5) {
        const bs = i.toString(2).padStart(this.numQubits, '0');
        terms.push(`(${c.format(precision)})|${bs}⟩`);
      }
    }
    return terms.length > 0 ? terms.join(" + ") : "0";
  }

  // Single Qubit Bloch coordinates for Qubit 0
  getBlochVector(qubitIndex = 0) {
    // If separable or 1-qubit, calculate <X>, <Y>, <Z>
    const n = this.numQubits;
    const targetMask = 1 << (n - 1 - qubitIndex);
    let x = 0, y = 0, z = 0;

    for (let i = 0; i < this.state.length; i++) {
      const bit = (i & targetMask) !== 0 ? 1 : 0;
      const prob = this.state[i].absSq();
      z += bit === 0 ? prob : -prob;

      if (bit === 0) {
        const i1 = i | targetMask;
        const a0 = this.state[i];
        const a1 = this.state[i1];
        // X expectation contribution: 2 * Re(a0* * a1)
        const cross = a0.conj().mul(a1);
        x += 2 * cross.re;
        // Y expectation contribution: 2 * Im(a0* * a1)
        y += 2 * cross.im;
      }
    }

    return { x, y, z, length: Math.hypot(x, y, z) };
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = QuantumEngine;
}
