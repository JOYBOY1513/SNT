/**
 * Quantum Mastery Lab - Complex Number Mathematics Engine
 * Supports arithmetic, polar form, conversions, and Dirac notation formatting.
 */

class Complex {
  constructor(re = 0, im = 0) {
    this.re = Number(re) || 0;
    this.im = Number(im) || 0;
  }

  static fromPolar(r, theta) {
    return new Complex(r * Math.cos(theta), r * Math.sin(theta));
  }

  add(other) {
    const o = Complex.ensure(other);
    return new Complex(this.re + o.re, this.im + o.im);
  }

  sub(other) {
    const o = Complex.ensure(other);
    return new Complex(this.re - o.re, this.im - o.im);
  }

  mul(other) {
    const o = Complex.ensure(other);
    return new Complex(
      this.re * o.re - this.im * o.im,
      this.re * o.im + this.im * o.re
    );
  }

  div(other) {
    const o = Complex.ensure(other);
    const denom = o.re * o.re + o.im * o.im;
    if (denom === 0) throw new Error("Division by zero in Complex arithmetic");
    return new Complex(
      (this.re * o.re + this.im * o.im) / denom,
      (this.im * o.re - this.re * o.im) / denom
    );
  }

  scale(scalar) {
    return new Complex(this.re * scalar, this.im * scalar);
  }

  conj() {
    return new Complex(this.re, -this.im);
  }

  abs() {
    return Math.hypot(this.re, this.im);
  }

  absSq() {
    return this.re * this.re + this.im * this.im;
  }

  phase() {
    return Math.atan2(this.im, this.re);
  }

  exp() {
    const r = Math.exp(this.re);
    return new Complex(r * Math.cos(this.im), r * Math.sin(this.im));
  }

  equals(other, tolerance = 1e-6) {
    const o = Complex.ensure(other);
    return Math.abs(this.re - o.re) <= tolerance && Math.abs(this.im - o.im) <= tolerance;
  }

  format(precision = 3) {
    const r = Math.abs(this.re) < 1e-6 ? 0 : Number(this.re.toFixed(precision));
    const i = Math.abs(this.im) < 1e-6 ? 0 : Number(this.im.toFixed(precision));

    if (i === 0) return `${r}`;
    if (r === 0) {
      if (i === 1) return `i`;
      if (i === -1) return `-i`;
      return `${i}i`;
    }
    const sign = i > 0 ? "+" : "-";
    const absI = Math.abs(i);
    const iStr = absI === 1 ? "i" : `${absI}i`;
    return `${r} ${sign} ${iStr}`;
  }

  formatPolar(precision = 3) {
    const r = this.abs();
    const theta = this.phase();
    if (r < 1e-6) return "0";
    const deg = Math.round((theta * 180) / Math.PI);
    return `${r.toFixed(precision)} ∠ ${deg}°`;
  }

  static ensure(val) {
    if (val instanceof Complex) return val;
    if (typeof val === 'number') return new Complex(val, 0);
    return new Complex(val?.re || 0, val?.im || 0);
  }

  static ZERO = new Complex(0, 0);
  static ONE = new Complex(1, 0);
  static I = new Complex(0, 1);
  static MINUS_I = new Complex(0, -1);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = Complex;
}
