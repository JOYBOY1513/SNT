/**
 * Quantum Mastery Lab - Interactive Quantum Quiz Arena
 * Comprehensive multi-difficulty quizzes with deep pedagogical explanations,
 * instant feedback, and mastery rank certification.
 */

const QUIZ_QUESTIONS = [
  {
    id: 1,
    tier: "Beginner",
    category: "Foundations",
    question: "If a qubit is in the state |ψ⟩ = (1/2)|0⟩ + (√3/2)|1⟩, what is the exact probability of measuring |0⟩?",
    options: [
      { text: "50%", correct: false },
      { text: "25% (1/4)", correct: true },
      { text: "75% (3/4)", correct: false },
      { text: "86.6%", correct: false }
    ],
    explanation: "According to Born's Rule, the probability of measuring basis state |0⟩ is the squared magnitude of its amplitude: P(0) = |α|² = (1/2)² = 1/4 = 25%. Similarly, P(1) = (√3/2)² = 3/4 = 75%."
  },
  {
    id: 2,
    tier: "Beginner",
    category: "Gates",
    question: "What state is produced when a Hadamard (H) gate is applied to the state |1⟩?",
    options: [
      { text: "|0⟩", correct: false },
      { text: "|+⟩ = (|0⟩ + |1⟩) / √2", correct: false },
      { text: "|-⟩ = (|0⟩ - |1⟩) / √2", correct: true },
      { text: "|i⟩ = (|0⟩ + i|1⟩) / √2", correct: false }
    ],
    explanation: "The Hadamard matrix maps H|0⟩ = |+⟩ and H|1⟩ = |-⟩ = (|0⟩ - |1⟩) / √2. The relative phase between |0⟩ and |1⟩ is 180° (π radians, represented by the minus sign)."
  },
  {
    id: 3,
    tier: "Beginner",
    category: "Bloch Sphere",
    question: "Where do the orthogonal eigenstates of the Pauli-Z operator (|0⟩ and |1⟩) lie on the Bloch sphere?",
    options: [
      { text: "On the equator (±X axes)", correct: false },
      { text: "At the North and South poles (±Z axis)", correct: true },
      { text: "At the ±Y axes", correct: false },
      { text: "At the exact center of the sphere", correct: false }
    ],
    explanation: "On the Bloch sphere, orthogonal quantum states are antipodal (180° apart). |0⟩ is at the North Pole (+Z axis, θ=0) and |1⟩ is at the South Pole (-Z axis, θ=π)."
  },
  {
    id: 4,
    tier: "Intermediate",
    category: "Gates & Math",
    question: "Why must every quantum gate operator U (without measurement) be a Unitary matrix (U† U = I)?",
    options: [
      { text: "To make quantum calculations run faster", correct: false },
      { text: "To conserve total probability (|α|² + |β|² = 1) and preserve inner products", correct: true },
      { text: "Because complex numbers cannot be inverted", correct: false },
      { text: "To prevent heat dissipation according to Landauer's principle only", correct: false }
    ],
    explanation: "Unitary transformations preserve the Euclidean norm in Hilbert space: ⟨Uψ|Uψ⟩ = ⟨ψ|U† U|ψ⟩ = ⟨ψ|ψ⟩ = 1. Non-unitary operations would cause total measurement probabilities to stray away from 100%, violating physical law."
  },
  {
    id: 5,
    tier: "Intermediate",
    category: "Entanglement",
    question: "Which of the following two-qubit states is a separable (product) state, NOT entangled?",
    options: [
      { text: "(|00⟩ + |11⟩) / √2", correct: false },
      { text: "(|01⟩ + |10⟩) / √2", correct: false },
      { text: "(|00⟩ + |01⟩ + |10⟩ + |11⟩) / 2", correct: true },
      { text: "(|00⟩ - |11⟩) / √2", correct: false }
    ],
    explanation: "The state (|00⟩ + |01⟩ + |10⟩ + |11⟩)/2 can be factored into (|0⟩ + |1⟩)/√2 ⊗ (|0⟩ + |1⟩)/√2 = |+⟩ ⊗ |+⟩. Because it can be decomposed into a tensor product of single-qubit states, its entanglement entropy is 0."
  },
  {
    id: 6,
    tier: "Intermediate",
    category: "Foundations",
    question: "What is the core consequence of the No-Cloning Theorem in quantum computing?",
    options: [
      { text: "Quantum computers cannot run recursive loops", correct: false },
      { text: "An unknown arbitrary quantum state cannot be copied perfectly", correct: true },
      { text: "Qubits cannot be measured more than once", correct: false },
      { text: "Two qubits can never have identical amplitudes", correct: false }
    ],
    explanation: "The linearity and unitarity of quantum mechanics forbid any physical operation that copies an unknown state: U(|ψ⟩|0⟩) ≠ |ψ⟩|ψ⟩. This is why classical repetition error correction codes cannot be used directly in quantum computers."
  },
  {
    id: 7,
    tier: "Advanced",
    category: "Algorithms",
    question: "In Grover's Search Algorithm, what is the geometric purpose of the Diffusion Operator (2|s⟩⟨s| - I)?",
    options: [
      { text: "To invert all amplitudes across the average (mean) amplitude", correct: true },
      { text: "To randomly shuffle the database items", correct: false },
      { text: "To measure the target item immediately", correct: false },
      { text: "To flip the phase of only the target item", correct: false }
    ],
    explanation: "The diffusion operator performs an 'inversion about the mean'. Since the Oracle flipped the target amplitude to negative, the average amplitude drops. Inverting across this lower mean boosts the target amplitude high into the positive while suppressing all non-targets!"
  },
  {
    id: 8,
    tier: "Advanced",
    category: "Protocols",
    question: "In the Quantum Teleportation protocol, why does transmitting the state not allow faster-than-light communication?",
    options: [
      { text: "Because the state is destroyed at Alice's station", correct: false },
      { text: "Because Bob requires 2 classical bits sent via subluminal channels to reconstruct the state", correct: true },
      { text: "Because qubits travel at the speed of sound", correct: false },
      { text: "Because quantum entanglement only works across microscopic distances", correct: false }
    ],
    explanation: "Before Bob receives the 2 classical measurement outcomes from Alice, Bob's qubit is in a maximally mixed state ρ_B = I/2 containing zero usable information. He cannot decode the teleported state until the classical bits arrive at or below the speed of light."
  },
  {
    id: 9,
    tier: "Advanced",
    category: "Hardware & QEC",
    question: "What is the key difference between coherence time T₁ and dephasing time T₂ in physical qubits?",
    options: [
      { text: "T₁ measures gate speed, while T₂ measures circuit depth", correct: false },
      { text: "T₁ is energy relaxation (bit flip 1→0), while T₂ is loss of relative phase information", correct: true },
      { text: "T₁ is software latency, while T₂ is hardware clock rate", correct: false },
      { text: "T₂ is always strictly greater than 2·T₁", correct: false }
    ],
    explanation: "T₁ (longitudinal relaxation) is the time constant for an excited qubit |1⟩ to decay back into |0⟩ by losing energy to the environment. T₂ (transverse dephasing) is the timescale over which the relative phase φ randomizes. Physically, T₂ is always bounded by T₂ ≤ 2T₁."
  },
  {
    id: 10,
    tier: "Advanced",
    category: "Entanglement",
    question: "What is the maximum correlation value S achievable in the CHSH Bell Inequality by classical physics vs. quantum mechanics?",
    options: [
      { text: "Classical: 1.0, Quantum: 2.0", correct: false },
      { text: "Classical: 2.0, Quantum: 2√2 ≈ 2.828 (Tsirelson's Bound)", correct: true },
      { text: "Classical: 2.0, Quantum: 4.0", correct: false },
      { text: "Classical: √2, Quantum: 2.0", correct: false }
    ],
    explanation: "Any classical local realistic model must satisfy S ≤ 2. Entangled quantum states violate this inequality, reaching Tsirelson's bound of S = 2√2 ≈ 2.8284. This mathematically proves nature is non-locally correlated."
  }
];

class QuizArena {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.userAnswers = {}; // questionId -> selectedOptionIndex
    this.currentFilter = "All";
    this.render();
  }

  setFilter(filter) {
    this.currentFilter = filter;
    this.render();
  }

  selectOption(qId, optIdx) {
    if (this.userAnswers[qId] !== undefined) return; // Answer locked once clicked
    this.userAnswers[qId] = optIdx;
    this.render();
  }

  resetQuiz() {
    this.userAnswers = {};
    this.render();
  }

  getScore() {
    let score = 0;
    let answered = 0;
    for (let q of QUIZ_QUESTIONS) {
      if (this.userAnswers[q.id] !== undefined) {
        answered++;
        if (q.options[this.userAnswers[q.id]].correct) {
          score++;
        }
      }
    }
    return { score, answered, total: QUIZ_QUESTIONS.length };
  }

  getRankTitle(percentage) {
    if (percentage === 100) return "🏆 Quantum Architect (Mastery)";
    if (percentage >= 80) return "⚡ Quantum Engineer";
    if (percentage >= 60) return "🔬 Qubit Craftsman";
    if (percentage >= 40) return "🌱 Quantum Apprentice";
    return "📘 Quantum Explorer";
  }

  render() {
    if (!this.container) return;

    const stats = this.getScore();
    const pct = stats.answered > 0 ? Math.round((stats.score / stats.answered) * 100) : 0;
    const rank = this.getRankTitle(pct);

    const filtered = this.currentFilter === "All"
      ? QUIZ_QUESTIONS
      : QUIZ_QUESTIONS.filter(q => q.tier === this.currentFilter || q.category === this.currentFilter);

    let html = `
      <div class="space-y-6">
        <!-- Header & Stats Card -->
        <div class="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 class="text-base font-bold text-white flex items-center space-x-2">
                <span>🧠 Quantum Mastery Assessment Arena</span>
              </h3>
              <p class="text-xs text-slate-400 mt-1">
                Test your conceptual and mathematical understanding across all difficulty tiers.
              </p>
            </div>
            <div class="flex items-center space-x-3 shrink-0">
              <div class="bg-slate-950/80 border border-slate-800 px-4 py-2 rounded-xl text-center">
                <div class="text-xs text-slate-400">Score</div>
                <div class="text-base font-mono font-bold text-cyan-400">${stats.score} / ${stats.answered}</div>
              </div>
              <div class="bg-slate-950/80 border border-slate-800 px-4 py-2 rounded-xl text-center">
                <div class="text-xs text-slate-400">Mastery Rank</div>
                <div class="text-xs font-semibold text-purple-300">${rank}</div>
              </div>
            </div>
          </div>

          <!-- Progress Bar -->
          <div class="w-full bg-slate-800/80 h-2 rounded-full mt-4 overflow-hidden">
            <div class="h-full bg-gradient-to-r from-cyan-500 to-indigo-500 rounded-full transition-all duration-300"
              style="width: ${(stats.answered / stats.total) * 100}%;"></div>
          </div>
          <div class="flex justify-between text-[11px] text-slate-400 mt-1">
            <span>${stats.answered} of ${stats.total} Answered</span>
            <span>Accuracy: ${pct}%</span>
          </div>

          <!-- Tier Filter Pills -->
          <div class="flex flex-wrap gap-2 mt-4 pt-3 border-t border-slate-800/80">
            ${['All', 'Beginner', 'Intermediate', 'Advanced'].map(f => `
              <button onclick="window.quizArena.setFilter('${f}')"
                class="px-3 py-1 text-xs rounded-lg font-medium transition-colors ${this.currentFilter === f ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}">
                ${f}
              </button>
            `).join('')}
            <button onclick="window.quizArena.resetQuiz()"
              class="ml-auto px-3 py-1 text-xs rounded-lg text-slate-400 hover:text-slate-200 bg-slate-800/60 border border-slate-700 transition-colors">
              ↺ Reset Answers
            </button>
          </div>
        </div>

        <!-- Question Cards -->
        <div class="space-y-4">
    `;

    filtered.forEach((q, idx) => {
      const userAnswer = this.userAnswers[q.id];
      const hasAnswered = userAnswer !== undefined;

      let tierBadgeClass = "bg-slate-800 text-slate-300";
      if (q.tier === "Beginner") tierBadgeClass = "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30";
      else if (q.tier === "Intermediate") tierBadgeClass = "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30";
      else if (q.tier === "Advanced") tierBadgeClass = "bg-purple-500/20 text-purple-300 border border-purple-500/30";

      html += `
        <div class="bg-slate-900/80 border border-slate-800/90 rounded-xl p-5 transition-all">
          <div class="flex items-center justify-between mb-3">
            <div class="flex items-center space-x-2">
              <span class="text-xs font-mono font-bold text-slate-400">Q${q.id}</span>
              <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${tierBadgeClass}">${q.tier}</span>
              <span class="text-[11px] text-slate-500">#${q.category}</span>
            </div>
            ${hasAnswered ? (
              q.options[userAnswer].correct
                ? '<span class="text-xs font-bold text-emerald-400 flex items-center space-x-1"><span>✓ Correct</span></span>'
                : '<span class="text-xs font-bold text-rose-400 flex items-center space-x-1"><span>✗ Incorrect</span></span>'
            ) : ''}
          </div>

          <p class="text-sm font-semibold text-white mb-4 leading-relaxed">${q.question}</p>

          <!-- Options Grid -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
      `;

      q.options.forEach((opt, oIdx) => {
        let optStyle = "bg-slate-950/80 border-slate-800 hover:border-cyan-500/60 hover:bg-slate-800/40 text-slate-300 cursor-pointer";

        if (hasAnswered) {
          if (opt.correct) {
            optStyle = "bg-emerald-950/40 border-emerald-500 text-emerald-200 font-semibold";
          } else if (userAnswer === oIdx && !opt.correct) {
            optStyle = "bg-rose-950/40 border-rose-500 text-rose-200 font-semibold";
          } else {
            optStyle = "bg-slate-950/40 border-slate-800/60 text-slate-500 opacity-60";
          }
        }

        html += `
          <div onclick="window.quizArena.selectOption(${q.id}, ${oIdx})"
            class="p-3 rounded-lg border text-xs flex items-center justify-between transition-all duration-150 ${optStyle}">
            <span>${opt.text}</span>
            ${hasAnswered && opt.correct ? '<span class="text-emerald-400 text-sm">✓</span>' : ''}
            ${hasAnswered && userAnswer === oIdx && !opt.correct ? '<span class="text-rose-400 text-sm">✗</span>' : ''}
          </div>
        `;
      });

      html += `</div>`;

      // Detailed Pedagogical Explanation Box
      if (hasAnswered) {
        html += `
          <div class="mt-4 p-3.5 rounded-lg bg-slate-950 border border-slate-800/80 text-xs text-slate-300 leading-relaxed animate-fadeIn">
            <span class="font-bold text-cyan-400 block mb-1">💡 Deep Explanation:</span>
            ${q.explanation}
          </div>
        `;
      }

      html += `</div>`;
    });

    html += `
        </div>
      </div>
    `;

    this.container.innerHTML = html;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { QUIZ_QUESTIONS, QuizArena };
}
