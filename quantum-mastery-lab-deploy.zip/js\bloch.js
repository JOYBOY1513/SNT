/**
 * Quantum Mastery Lab - 3D Interactive Bloch Sphere Visualizer
 * Pure HTML5 Canvas 3D projection engine with spherical interpolation and gate animations.
 */

class BlochSphere {
  constructor(canvasId, options = {}) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');

    // 3D camera angles
    this.rotX = options.rotX ?? 0.35; // pitch
    this.rotY = options.rotY ?? -0.65; // yaw
    this.zoom = options.zoom ?? 140;

    // State vector spherical angles
    this.theta = 0; // [0, Math.PI]
    this.phi = 0;   // [0, 2*Math.PI]

    // Animation interpolation
    this.targetTheta = 0;
    this.targetPhi = 0;
    this.animating = false;

    // Interaction handling
    this.isDragging = false;
    this.lastMouseX = 0;
    this.lastMouseY = 0;

    this.onStateChange = options.onStateChange || null;

    this.initEvents();
    this.resize();
    this.render();
  }

  resize() {
    if (!this.canvas) return;
    const rect = this.canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    this.canvas.width = (rect.width || 360) * dpr;
    this.canvas.height = (rect.height || 360) * dpr;
    this.ctx.scale(dpr, dpr);
    this.displayWidth = rect.width || 360;
    this.displayHeight = rect.height || 360;
    this.zoom = Math.min(this.displayWidth, this.displayHeight) * 0.36;
  }

  initEvents() {
    window.addEventListener('resize', () => {
      this.resize();
      this.render();
    });

    this.canvas.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.lastMouseX = e.clientX;
      this.lastMouseY = e.clientY;
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      const dx = e.clientX - this.lastMouseX;
      const dy = e.clientY - this.lastMouseY;
      this.rotY += dx * 0.01;
      this.rotX += dy * 0.01;
      // Clamp pitch to avoid gimbal lock
      this.rotX = Math.max(-Math.PI / 2 + 0.05, Math.min(Math.PI / 2 - 0.05, this.rotX));
      this.lastMouseX = e.clientX;
      this.lastMouseY = e.clientY;
      this.render();
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    // Touch support for tablets and mobile
    this.canvas.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) {
        this.isDragging = true;
        this.lastMouseX = e.touches[0].clientX;
        this.lastMouseY = e.touches[0].clientY;
      }
    }, { passive: true });

    window.addEventListener('touchmove', (e) => {
      if (!this.isDragging || e.touches.length !== 1) return;
      const dx = e.touches[0].clientX - this.lastMouseX;
      const dy = e.touches[0].clientY - this.lastMouseY;
      this.rotY += dx * 0.01;
      this.rotX += dy * 0.01;
      this.rotX = Math.max(-Math.PI / 2 + 0.05, Math.min(Math.PI / 2 - 0.05, this.rotX));
      this.lastMouseX = e.touches[0].clientX;
      this.lastMouseY = e.touches[0].clientY;
      this.render();
    }, { passive: true });

    window.addEventListener('touchend', () => {
      this.isDragging = false;
    });
  }

  setAngles(theta, phi, animate = true) {
    // Normalize angles
    theta = Math.max(0, Math.min(Math.PI, theta));
    phi = (phi % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI);

    if (!animate) {
      this.theta = theta;
      this.phi = phi;
      this.targetTheta = theta;
      this.targetPhi = phi;
      this.render();
      this.notifyChange();
      return;
    }

    this.targetTheta = theta;
    this.targetPhi = phi;

    if (!this.animating) {
      this.animating = true;
      this.animateStep();
    }
  }

  animateStep() {
    if (!this.animating) return;

    // Smooth shortest-path angular interpolation
    const step = 0.15;
    let dTheta = this.targetTheta - this.theta;
    let dPhi = this.targetPhi - this.phi;

    // Handle 2pi wraparound for phi
    if (dPhi > Math.PI) dPhi -= 2 * Math.PI;
    if (dPhi < -Math.PI) dPhi += 2 * Math.PI;

    if (Math.abs(dTheta) < 0.005 && Math.abs(dPhi) < 0.005) {
      this.theta = this.targetTheta;
      this.phi = this.targetPhi;
      this.animating = false;
      this.render();
      this.notifyChange();
      return;
    }

    this.theta += dTheta * step;
    this.phi += dPhi * step;
    this.phi = (this.phi % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI);

    this.render();
    this.notifyChange();
    requestAnimationFrame(() => this.animateStep());
  }

  notifyChange() {
    if (this.onStateChange) {
      const coords = this.getCartesian();
      const a = Math.cos(this.theta / 2);
      const bRe = Math.cos(this.phi) * Math.sin(this.theta / 2);
      const bIm = Math.sin(this.phi) * Math.sin(this.theta / 2);
      this.onStateChange({
        theta: this.theta,
        phi: this.phi,
        x: coords.x,
        y: coords.y,
        z: coords.z,
        alpha: new Complex(a, 0),
        beta: new Complex(bRe, bIm),
        prob0: a * a,
        prob1: bRe * bRe + bIm * bIm
      });
    }
  }

  getCartesian(th = this.theta, ph = this.phi) {
    return {
      x: Math.sin(th) * Math.cos(ph),
      y: Math.sin(th) * Math.sin(ph),
      z: Math.cos(th)
    };
  }

  // 3D coordinate transformation to 2D screen
  project(x, y, z) {
    // Rotate around Y axis (yaw)
    const cosY = Math.cos(this.rotY);
    const sinY = Math.sin(this.rotY);
    const x1 = x * cosY + y * sinY;
    const y1 = -x * sinY + y * cosY;
    const z1 = z;

    // Rotate around X axis (pitch)
    const cosX = Math.cos(this.rotX);
    const sinX = Math.sin(this.rotX);
    const x2 = x1;
    const y2 = y1 * cosX - z1 * sinX;
    const z2 = y1 * sinX + z1 * cosX;

    const cx = this.displayWidth / 2;
    const cy = this.displayHeight / 2;

    return {
      sx: cx + x2 * this.zoom,
      sy: cy - z2 * this.zoom, // Invert Z so +Z is UP (|0>)
      depth: y2
    };
  }

  applyGate(gateName) {
    const coords = this.getCartesian();
    const g = gateName.toUpperCase();
    let newX = coords.x, newY = coords.y, newZ = coords.z;

    if (g === 'X') {
      // Rotation of pi around X axis: (x, y, z) -> (x, -y, -z)
      newY = -coords.y;
      newZ = -coords.z;
    } else if (g === 'Y') {
      // Rotation of pi around Y axis: (x, y, z) -> (-x, y, -z)
      newX = -coords.x;
      newZ = -coords.z;
    } else if (g === 'Z') {
      // Rotation of pi around Z axis: (x, y, z) -> (-x, -y, z)
      newX = -coords.x;
      newY = -coords.y;
    } else if (g === 'H') {
      // Hadamard swaps X and Z: (x, y, z) -> (z, -y, x)
      newX = coords.z;
      newY = -coords.y;
      newZ = coords.x;
    } else if (g === 'S') {
      // 90 deg rotation around Z axis: (x, y, z) -> (-y, x, z)
      newX = -coords.y;
      newY = coords.x;
    } else if (g === 'T') {
      // 45 deg rotation around Z axis
      const cos45 = Math.SQRT1_2;
      newX = coords.x * cos45 - coords.y * cos45;
      newY = coords.x * cos45 + coords.y * cos45;
    }

    // Convert (newX, newY, newZ) back to theta, phi
    const r = Math.hypot(newX, newY, newZ) || 1;
    const theta = Math.acos(Math.max(-1, Math.min(1, newZ / r)));
    let phi = Math.atan2(newY, newX);
    if (phi < 0) phi += 2 * Math.PI;

    this.setAngles(theta, phi, true);
  }

  render() {
    const ctx = this.ctx;
    const w = this.displayWidth;
    const h = this.displayHeight;

    ctx.clearRect(0, 0, w, h);

    // Glowing background aura
    const gradient = ctx.createRadialGradient(w / 2, h / 2, 10, w / 2, h / 2, this.zoom * 1.5);
    gradient.addColorStop(0, 'rgba(30, 41, 59, 0.4)');
    gradient.addColorStop(1, 'rgba(15, 23, 42, 0)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, w, h);

    // Draw Equator & Latitude rings
    this.drawCircle3D([0, 0, 0], 1, 'z', 'rgba(56, 189, 248, 0.4)', 1.5, [4, 4]); // Equator
    this.drawCircle3D([0, 0, 0], 1, 'x', 'rgba(148, 163, 184, 0.2)', 1); // Prime meridian
    this.drawCircle3D([0, 0, 0], 1, 'y', 'rgba(148, 163, 184, 0.2)', 1); // YZ plane

    // Draw coordinate axes
    this.drawAxis([0, 0, 0], [1.3, 0, 0], 'rgba(239, 68, 68, 0.8)', '+X (|+⟩)');
    this.drawAxis([0, 0, 0], [-1.2, 0, 0], 'rgba(239, 68, 68, 0.3)', '|-⟩');
    this.drawAxis([0, 0, 0], [0, 1.3, 0], 'rgba(34, 197, 94, 0.8)', '+Y (|i⟩)');
    this.drawAxis([0, 0, 0], [0, -1.2, 0], 'rgba(34, 197, 94, 0.3)', '|-i⟩');
    this.drawAxis([0, 0, 0], [0, 0, 1.3], 'rgba(59, 130, 246, 0.9)', '+Z (|0⟩)');
    this.drawAxis([0, 0, 0], [0, 0, -1.3], 'rgba(168, 85, 247, 0.9)', '-Z (|1⟩)');

    // Draw state vector arrow |psi>
    const pos = this.getCartesian();
    this.drawVector([0, 0, 0], [pos.x, pos.y, pos.z]);

    // Draw projection lines onto XY plane
    const projPlane = this.project(pos.x, pos.y, 0);
    const center = this.project(0, 0, 0);
    const arrowHead = this.project(pos.x, pos.y, pos.z);

    ctx.save();
    ctx.setLineDash([3, 3]);
    ctx.strokeStyle = 'rgba(234, 179, 8, 0.5)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(arrowHead.sx, arrowHead.sy);
    ctx.lineTo(projPlane.sx, projPlane.sy);
    ctx.lineTo(center.sx, center.sy);
    ctx.stroke();
    ctx.restore();
  }

  drawCircle3D(center, radius, plane, color, lineWidth = 1, dash = []) {
    const ctx = this.ctx;
    const segments = 64;
    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = lineWidth;
    if (dash.length > 0) ctx.setLineDash(dash);

    ctx.beginPath();
    for (let i = 0; i <= segments; i++) {
      const angle = (i / segments) * 2 * Math.PI;
      let x = 0, y = 0, z = 0;
      if (plane === 'z') {
        x = radius * Math.cos(angle);
        y = radius * Math.sin(angle);
      } else if (plane === 'x') {
        y = radius * Math.cos(angle);
        z = radius * Math.sin(angle);
      } else if (plane === 'y') {
        x = radius * Math.cos(angle);
        z = radius * Math.sin(angle);
      }
      const p = this.project(center[0] + x, center[1] + y, center[2] + z);
      if (i === 0) ctx.moveTo(p.sx, p.sy);
      else ctx.lineTo(p.sx, p.sy);
    }
    ctx.stroke();
    ctx.restore();
  }

  drawAxis(from, to, color, label) {
    const ctx = this.ctx;
    const p1 = this.project(...from);
    const p2 = this.project(...to);

    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(p1.sx, p1.sy);
    ctx.lineTo(p2.sx, p2.sy);
    ctx.stroke();

    if (label) {
      ctx.fillStyle = color;
      ctx.font = '11px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, p2.sx + (p2.sx > p1.sx ? 10 : -10), p2.sy + (p2.sy > p1.sy ? 10 : -10));
    }
    ctx.restore();
  }

  drawVector(from, to) {
    const ctx = this.ctx;
    const p1 = this.project(...from);
    const p2 = this.project(...to);

    ctx.save();
    // Glowing line effect
    ctx.shadowColor = '#38bdf8';
    ctx.shadowBlur = 10;
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    ctx.moveTo(p1.sx, p1.sy);
    ctx.lineTo(p2.sx, p2.sy);
    ctx.stroke();

    // Arrowhead point dot
    ctx.fillStyle = '#0284c7';
    ctx.beginPath();
    ctx.arc(p2.sx, p2.sy, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(p2.sx, p2.sy, 3, 0, Math.PI * 2);
    ctx.fill();

    // Label |psi>
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 14px system-ui, -apple-system, sans-serif';
    ctx.fillText('|ψ⟩', p2.sx + 12, p2.sy - 8);

    ctx.restore();
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = BlochSphere;
}
