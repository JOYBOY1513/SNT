/**
 * Quantum Mastery Lab - Advanced Interactive Curriculum & Masterclass Modules
 * Demystifies the hardest concepts in quantum mechanics and quantum computing
 * with mathematical rigor, visual intuition, and live interactive experiments.
 */

const CURRICULUM_DATA = [
  {
    id: "module-1",
    title: "1. The Hilbert Space Reality",
    subtitle: "Debunking the '0 and 1 at Once' Pop-Science Myth",
    badge: "Foundations",
    badgeColor: "cyan",
    readTime: "7 min read",
    content: `
      <div class="space-y-6">
        <div class="bg-cyan-950/30 border border-cyan-500/30 rounded-xl p-4 text-cyan-200">
          <p class="font-semibold text-sm">💡 The Mental Shift:</p>
          <p class="text-xs text-slate-300 mt-1">
            Pop-science often says: <em>"A classical bit is 0 or 1, but a qubit is both 0 and 1 at the same time."</em>
            This is misleading. A qubit is not a coin spinning indefinitely. A qubit is a <strong>unit vector in a 2-dimensional complex Hilbert space $\\mathbb{C}^2$</strong>.
          </p>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">Dirac Bra-Ket Notation</h4>
          <p class="text-sm text-slate-300 leading-relaxed">
            In quantum mechanics, state vectors are represented by "kets" $|\\psi\\rangle$. The computational basis consists of two orthonormal basis vectors:
          </p>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-xs">
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-cyan-400 font-bold">|0⟩</span> = <span class="text-slate-300">[1, 0]ᵀ</span>
              <p class="text-[11px] text-slate-400 mt-1 font-sans">Ground state / North pole of Bloch sphere.</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-purple-400 font-bold">|1⟩</span> = <span class="text-slate-300">[0, 1]ᵀ</span>
              <p class="text-[11px] text-slate-400 mt-1 font-sans">Excited state / South pole of Bloch sphere.</p>
            </div>
          </div>
          <p class="text-sm text-slate-300 leading-relaxed">
            A general pure state is a linear combination (superposition):
          </p>
          <div class="bg-slate-900/90 border border-slate-800 p-3.5 rounded-lg text-center font-mono text-sm text-cyan-300">
            |ψ⟩ = α|0⟩ + β|1⟩, &nbsp; where α, β ∈ ℂ &nbsp; and &nbsp; |α|² + |β|² = 1
          </div>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">Born's Rule & Wavefunction Collapse</h4>
          <p class="text-sm text-slate-300 leading-relaxed">
            When you measure $|\\psi\\rangle$ in the computational basis, you do <strong>not</strong> observe the continuous vector. The state probabilistically collapses:
          </p>
          <ul class="list-disc pl-5 text-xs text-slate-300 space-y-1.5 font-mono">
            <li>P(Measure 0) = |α|² = |⟨0|ψ⟩|²</li>
            <li>P(Measure 1) = |β|² = |⟨1|ψ⟩|²</li>
          </ul>
          <p class="text-xs text-slate-400 leading-relaxed">
            Notice that the probabilities must sum to 1: $|\\alpha|^2 + |\\beta|^2 = 1$. This is why the state vector must always remain on the surface of the unit sphere!
          </p>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">Global Phase vs. Relative Phase</h4>
          <p class="text-sm text-slate-300 leading-relaxed">
            Two states that differ only by a <strong>global phase</strong> $e^{i\\theta}|\\psi\\rangle$ are physically identical and indistinguishable by any experiment:
          </p>
          <div class="bg-slate-900/90 border border-slate-800 p-3 rounded-lg text-center font-mono text-xs text-amber-300">
            |e^{iθ} α|² = |e^{iθ}|² |α|² = 1 · |α|² = |α|²
          </div>
          <p class="text-sm text-slate-300 leading-relaxed">
            However, <strong>relative phase</strong> $\\phi$ between $|0\\rangle$ and $|1\\rangle$ determines quantum interference and changes the state completely:
          </p>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-xs">
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-emerald-400 font-bold">|+⟩</span> = (|0⟩ + |1⟩) / √2
              <p class="text-[11px] text-slate-400 mt-1 font-sans">Relative phase = 0°. Lies on the +X axis.</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-rose-400 font-bold">|-⟩</span> = (|0⟩ - |1⟩) / √2
              <p class="text-[11px] text-slate-400 mt-1 font-sans">Relative phase = 180° (π). Lies on the -X axis.</p>
            </div>
          </div>
        </div>
      </div>
    `
  },
  {
    id: "module-2",
    title: "2. Quantum Gates & Unitarity",
    subtitle: "Why All Quantum Computing is Reversible Linear Algebra",
    badge: "Linear Algebra",
    badgeColor: "indigo",
    readTime: "8 min read",
    content: `
      <div class="space-y-6">
        <div class="bg-indigo-950/30 border border-indigo-500/30 rounded-xl p-4 text-indigo-200">
          <p class="font-semibold text-sm">📐 Core Axiom:</p>
          <p class="text-xs text-slate-300 mt-1">
            Every valid quantum gate without measurement corresponds to a <strong>Unitary Matrix</strong> $U$ satisfying:
            <span class="font-mono text-indigo-300 block my-1">U† U = U U† = I</span>
            where $U^\\dagger = (U^*)^T$ is the conjugate transpose (Hermitian adjoint).
          </p>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">Why Must Operations Be Unitary?</h4>
          <p class="text-sm text-slate-300 leading-relaxed">
            Unitary operators preserve vector norms and inner products:
          </p>
          <div class="bg-slate-900/90 border border-slate-800 p-3.5 rounded-lg text-center font-mono text-xs text-indigo-300">
            ⟨Uψ|Uψ⟩ = ⟨ψ|U† U|ψ⟩ = ⟨ψ|I|ψ⟩ = ⟨ψ|ψ⟩ = 1
          </div>
          <p class="text-xs text-slate-400">
            If a quantum gate were not unitary, the sum of measurement probabilities would change away from 100%, violating the fundamental laws of probability and quantum mechanics.
          </p>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">The No-Cloning Theorem</h4>
          <p class="text-sm text-slate-300 leading-relaxed">
            One of the deepest results in quantum physics is that <strong>you cannot create an identical copy of an arbitrary unknown quantum state</strong>.
          </p>
          <div class="bg-slate-900 p-3.5 rounded-lg border border-slate-800 text-xs text-slate-300 space-y-2">
            <p>Suppose a unitary cloner existed such that:</p>
            <p class="font-mono text-cyan-300">U(|ψ⟩|0⟩) = |ψ⟩|ψ⟩ &nbsp; and &nbsp; U(|φ⟩|0⟩) = |φ⟩|φ⟩</p>
            <p>Taking the inner product of both sides:</p>
            <p class="font-mono text-amber-300">⟨ψ|φ⟩ · ⟨0|0⟩ = (⟨ψ|φ⟩)² &nbsp; ⇒ &nbsp; ⟨ψ|φ⟩ = (⟨ψ|φ⟩)²</p>
            <p class="text-slate-400">
              This equation is ONLY satisfied if $\\langle\\psi|\\phi\\rangle = 0$ (orthogonal states) or $\\langle\\psi|\\phi\\rangle = 1$ (identical states). Therefore, no universal quantum cloning machine can exist!
            </p>
          </div>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">Common Single-Qubit Unitaries</h4>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-xs">
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-cyan-400 font-bold">H (Hadamard):</span>
              <pre class="text-[11px] text-slate-300 mt-1">1/√2 [ 1   1 ]
     [ 1  -1 ]</pre>
              <p class="font-sans text-[11px] text-slate-400 mt-1">Creates equal superposition from computational basis.</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-rose-400 font-bold">X (Pauli-X / NOT):</span>
              <pre class="text-[11px] text-slate-300 mt-1">[ 0  1 ]
[ 1  0 ]</pre>
              <p class="font-sans text-[11px] text-slate-400 mt-1">Bit flip: maps |0⟩ ↔ |1⟩.</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-emerald-400 font-bold">Z (Pauli-Z):</span>
              <pre class="text-[11px] text-slate-300 mt-1">[ 1   0 ]
[ 0  -1 ]</pre>
              <p class="font-sans text-[11px] text-slate-400 mt-1">Phase flip: leaves |0⟩ unchanged, maps |1⟩ → -|1⟩.</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-amber-400 font-bold">S Gate (√Z):</span>
              <pre class="text-[11px] text-slate-300 mt-1">[ 1  0 ]
[ 0  i ]</pre>
              <p class="font-sans text-[11px] text-slate-400 mt-1">Quarter turn around Z axis (90° phase shift).</p>
            </div>
          </div>
        </div>
      </div>
    `
  },
  {
    id: "module-3",
    title: "3. Quantum Interference",
    subtitle: "The Real Engine of Quantum Speedup",
    badge: "Key Mechanism",
    badgeColor: "emerald",
    readTime: "6 min read",
    content: `
      <div class="space-y-6">
        <div class="bg-emerald-950/30 border border-emerald-500/30 rounded-xl p-4 text-emerald-200">
          <p class="font-semibold text-sm">🌊 The Crucial Difference:</p>
          <p class="text-xs text-slate-300 mt-1">
            Superposition alone provides <strong>no computational speedup</strong> over classical randomized algorithms.
            The actual computational power comes from <strong>Quantum Interference</strong>: probability amplitudes can have negative or complex signs and cancel each other out!
          </p>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">Classical Probability vs. Quantum Amplitudes</h4>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-amber-400 font-bold font-mono">Classical Probability (p):</span>
              <p class="text-slate-300 mt-1">
                Probabilities are non-negative real numbers $p \\in [0, 1]$.
                Multiple paths always add positively:
              </p>
              <div class="font-mono text-[11px] text-slate-400 mt-1">P_total = P_path1 + P_path2 ≥ P_path1</div>
              <p class="text-slate-400 mt-1">No cancellation is possible.</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-cyan-400 font-bold font-mono">Quantum Amplitudes (α):</span>
              <p class="text-slate-300 mt-1">
                Amplitudes are complex numbers $\\alpha \\in \\mathbb{C}$.
                Total amplitude is the sum of path amplitudes:
              </p>
              <div class="font-mono text-[11px] text-cyan-300 mt-1">α_total = α_path1 + α_path2</div>
              <p class="text-slate-400 mt-1">
                If $\\alpha_1 = +\\frac{1}{2}$ and $\\alpha_2 = -\\frac{1}{2}$, then $\\alpha_{total} = 0$! Complete destructive cancellation.
              </p>
            </div>
          </div>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">How Quantum Algorithms Actually Work</h4>
          <p class="text-sm text-slate-300 leading-relaxed">
            Every quantum algorithm follows this three-step blueprint:
          </p>
          <ol class="list-decimal pl-5 text-xs text-slate-300 space-y-2">
            <li><strong>State Preparation:</strong> Put the register into an equal superposition of all possible inputs using Hadamard gates.</li>
            <li><strong>Interference Engineering:</strong> Design unitary operations and oracles that induce destructive interference on incorrect candidate solutions and constructive interference on the correct answer.</li>
            <li><strong>Measurement:</strong> Measure the register. Because all wrong answers have amplitude near 0, the correct answer appears with near 100% probability!</li>
          </ol>
        </div>
      </div>
    `
  },
  {
    id: "module-4",
    title: "4. Entanglement & Bell's Theorem",
    subtitle: "From Einstein's EPR Paradox to Verifiable Non-Locality",
    badge: "Entanglement",
    badgeColor: "purple",
    readTime: "9 min read",
    content: `
      <div class="space-y-6">
        <div class="bg-purple-950/30 border border-purple-500/30 rounded-xl p-4 text-purple-200">
          <p class="font-semibold text-sm">🌌 What is Entanglement?</p>
          <p class="text-xs text-slate-300 mt-1">
            Two qubits are <strong>entangled</strong> when their joint state cannot be decomposed into a tensor product of two independent single-qubit states:
            <span class="font-mono text-purple-300 block my-1">|ψ⟩ ≠ |ψ_A⟩ ⊗ |ψ_B⟩</span>
            Measuring qubit A immediately determines the outcome of measuring qubit B, regardless of distance.
          </p>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">The Four Canonical Bell States</h4>
          <p class="text-sm text-slate-300 leading-relaxed">
            The Bell basis forms a complete orthonormal basis of maximally entangled two-qubit states:
          </p>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-xs">
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-cyan-400 font-bold">|Φ⁺⟩</span> = (|00⟩ + |11⟩) / √2
              <p class="text-[11px] text-slate-400 font-sans mt-1">Created with H on q0, then CNOT(0, 1).</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-indigo-400 font-bold">|Φ⁻⟩</span> = (|00⟩ - |11⟩) / √2
              <p class="text-[11px] text-slate-400 font-sans mt-1">Created with X then H on q0, then CNOT(0, 1).</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-rose-400 font-bold">|Ψ⁺⟩</span> = (|01⟩ + |10⟩) / √2
              <p class="text-[11px] text-slate-400 font-sans mt-1">Correlated anti-aligned states.</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-amber-400 font-bold">|Ψ⁻⟩</span> = (|01⟩ - |10⟩) / √2
              <p class="text-[11px] text-slate-400 font-sans mt-1">The Singlet state (invariant under all rotations).</p>
            </div>
          </div>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">The CHSH Bell Inequality Test</h4>
          <p class="text-sm text-slate-300 leading-relaxed">
            In 1964, John Stewart Bell proved that no classical local hidden variable theory could reproduce the predictions of quantum mechanics.
            The Clauser-Horne-Shimony-Holt (CHSH) inequality states:
          </p>
          <div class="bg-slate-900/90 border border-slate-800 p-3.5 rounded-lg text-center font-mono text-xs text-purple-300">
            S = |E(a, b) - E(a, b') + E(a', b) + E(a', b')| ≤ 2.0 &nbsp; (Classical Limit)
          </div>
          <p class="text-sm text-slate-300 leading-relaxed">
            When measured with entangled Bell states at optimal detector angles ($0, \\pi/4, \\pi/8, 3\\pi/8$), quantum mechanics achieves:
          </p>
          <div class="bg-slate-900/90 border border-slate-800 p-3.5 rounded-lg text-center font-mono text-sm text-emerald-400">
            S_quantum = 2√2 ≈ 2.8284 > 2.0 &nbsp; (Tsirelson's Bound)
          </div>
          <p class="text-xs text-slate-400 leading-relaxed">
            This violation has been experimentally confirmed in loophole-free experiments across the world (awarded the 2022 Nobel Prize in Physics).
          </p>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">Why No Faster-Than-Light Signaling?</h4>
          <p class="text-sm text-slate-300 leading-relaxed">
            Despite non-local correlations, the <strong>No-Communication Theorem</strong> guarantees that entanglement cannot transmit classical messages instantaneously:
          </p>
          <p class="text-xs text-slate-400 leading-relaxed">
            When Alice measures her qubit, her local density matrix reduces to $\\rho_A = \\frac{1}{2}I$ (a completely random 50/50 mix). Bob's local density matrix $\\rho_B = \\text{Tr}_A(\\rho)$ remains $\\frac{1}{2}I$ regardless of whether Alice measured or not. Bob only sees correlation once Alice sends her measurement outcome via classical light-speed channels!
          </p>
        </div>
      </div>
    `
  },
  {
    id: "module-5",
    title: "5. Quantum Teleportation",
    subtitle: "Transferring Quantum Information Without Physical Moving",
    badge: "Protocols",
    badgeColor: "rose",
    readTime: "8 min read",
    content: `
      <div class="space-y-6">
        <div class="bg-rose-950/30 border border-rose-500/30 rounded-xl p-4 text-rose-200">
          <p class="font-semibold text-sm">📡 The Quantum Teleportation Protocol:</p>
          <p class="text-xs text-slate-300 mt-1">
            Alice has an unknown qubit state $|\psi\rangle = \alpha|0\rangle + \beta|1\rangle$. She wishes to transmit this exact state to Bob.
            Using <strong>1 shared Bell pair</strong> and <strong>2 classical bits</strong> of communication, the state is faithfully reconstructed at Bob's end without violating the No-Cloning theorem (Alice's original state is destroyed).
          </p>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">The Step-by-Step Circuit Workflow</h4>
          <div class="space-y-2 text-xs text-slate-300">
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-cyan-400 font-bold font-mono">Step 1: Entangled Pair Distribution</span>
              <p class="text-slate-400 mt-1">Qubit 1 and Qubit 2 are prepared in Bell state $|\Phi^+\rangle = \frac{|00\rangle + |11\rangle}{\sqrt{2}}$. Alice holds Qubit 0 and Qubit 1; Bob holds Qubit 2.</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-indigo-400 font-bold font-mono">Step 2: Bell Measurement at Alice</span>
              <p class="text-slate-400 mt-1">Alice applies CNOT(target=1, control=0), followed by Hadamard on Qubit 0.</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-amber-400 font-bold font-mono">Step 3: Classical Transmission</span>
              <p class="text-slate-400 mt-1">Alice measures Qubits 0 and 1, producing two classical bits $(m_0, m_1)$, and sends them to Bob over a classical network.</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-emerald-400 font-bold font-mono">Step 4: Bob's Unitary Correction</span>
              <p class="text-slate-400 mt-1">Based on the classical bits, Bob applies corrections to Qubit 2:</p>
              <ul class="list-disc pl-5 mt-1 font-mono text-slate-300 space-y-0.5">
                <li>If 00: Bob applies Identity (I)</li>
                <li>If 01: Bob applies X (bit-flip)</li>
                <li>If 10: Bob applies Z (phase-flip)</li>
                <li>If 11: Bob applies ZX (bit and phase flip)</li>
              </ul>
              <p class="text-emerald-300 font-bold mt-1">Bob's qubit is now precisely $|\psi\rangle = \alpha|0\rangle + \beta|1\rangle$!</p>
            </div>
          </div>
        </div>
      </div>
    `
  },
  {
    id: "module-6",
    title: "6. Grover's Search Algorithm",
    subtitle: "Quadratic Speedup via Geometric Amplitude Amplification",
    badge: "Algorithms",
    badgeColor: "amber",
    readTime: "10 min read",
    content: `
      <div class="space-y-6">
        <div class="bg-amber-950/30 border border-amber-500/30 rounded-xl p-4 text-amber-200">
          <p class="font-semibold text-sm">🔍 The Grover Advantage:</p>
          <p class="text-xs text-slate-300 mt-1">
            To find 1 marked item in an unsorted database of $N$ items, a classical algorithm requires $O(N)$ queries on average.
            Lov Grover's quantum algorithm finds the item in <strong>$O(\\sqrt{N})$</strong> queries! For a database of 1 trillion items ($10^{12}$), classical requires $5 \\times 10^{11}$ queries, whereas Grover requires only $10^6$ queries!
          </p>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">The 2D Geometric Subspace</h4>
          <p class="text-sm text-slate-300 leading-relaxed">
            The entire state space can be viewed as a 2D plane spanned by two orthonormal vectors:
          </p>
          <ul class="list-disc pl-5 text-xs text-slate-300 space-y-1 font-mono">
            <li><span class="text-cyan-400">|ω⟩</span>: The target marked state.</li>
            <li><span class="text-purple-400">|s'⟩</span>: The uniform superposition of all non-target states.</li>
          </ul>
          <p class="text-xs text-slate-400">
            The initial state is the uniform superposition $|s\rangle = H^{\otimes n}|0\rangle^{\otimes n} = \cos(\theta/2)|s'\rangle + \sin(\theta/2)|\omega\rangle$, where $\sin(\theta/2) = \frac{1}{\sqrt{N}}$.
          </p>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">The Grover Iteration: Two Reflections</h4>
          <p class="text-sm text-slate-300 leading-relaxed">
            Each Grover iteration consists of two geometric reflections:
          </p>
          <div class="space-y-2 text-xs">
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-rose-400 font-bold font-mono">1. Oracle Reflection: R_ω = I - 2|ω⟩⟨ω|</span>
              <p class="text-slate-300 mt-1">Flips the phase of the target state: $|\omega\rangle \to -|\omega\rangle$, while leaving all other states untouched.</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-emerald-400 font-bold font-mono">2. Diffusion Reflection: R_s = 2|s⟩⟨s| - I</span>
              <p class="text-slate-300 mt-1">Inversion about the mean! Flips every amplitude across the average amplitude.</p>
            </div>
          </div>
          <p class="text-xs text-slate-300 leading-relaxed">
            The composition of two reflections is a pure rotation! In each step, the state rotates toward the target $|\omega\rangle$ by an angle of $\theta \approx \frac{2}{\sqrt{N}}$.
            After $R \approx \frac{\pi}{4}\sqrt{N}$ iterations, the state vector aligns with $|\omega\rangle$, giving measurement probability $\approx 100\%$!
          </p>
        </div>
      </div>
    `
  },
  {
    id: "module-7",
    title: "7. Decoherence & Quantum Error Correction",
    subtitle: "Protecting Fragile Qubits from Environmental Noise",
    badge: "Hardware & QEC",
    badgeColor: "emerald",
    readTime: "9 min read",
    content: `
      <div class="space-y-6">
        <div class="bg-teal-950/30 border border-teal-500/30 rounded-xl p-4 text-teal-200">
          <p class="font-semibold text-sm">🛡️ The Engineering Challenge:</p>
          <p class="text-xs text-slate-300 mt-1">
            Physical qubits interact with stray thermal photons, cosmic rays, and magnetic fluctuations.
            This causes <strong>Decoherence</strong>: the loss of quantum superposition and phase coherence over time.
          </p>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">Characteristic Relaxation Times: T₁ vs T₂</h4>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-rose-400 font-bold">T₁ (Energy Relaxation / Bit Flip):</span>
              <p class="font-sans text-slate-300 mt-1">Time for an excited state |1⟩ to decay spontaneously into ground state |0⟩ via energy loss.</p>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-cyan-400 font-bold">T₂ (Dephasing / Phase Flip):</span>
              <p class="font-sans text-slate-300 mt-1">Time for relative phase information between |0⟩ and |1⟩ to randomize. Always bounded by $T_2 \le 2T_1$.</p>
            </div>
          </div>
        </div>

        <div class="space-y-3">
          <h4 class="text-base font-semibold text-white">How Quantum Error Correction Bypasses No-Cloning</h4>
          <p class="text-sm text-slate-300 leading-relaxed">
            In classical computing, you repeat bits: $0 \to 000, 1 \to 111$.
            In quantum computing, you cannot clone $|\psi\rangle$, and direct measurement destroys superposition!
            Instead, we encode 1 logical qubit into an entangled subspace of multiple physical qubits:
          </p>
          <div class="bg-slate-900/90 border border-slate-800 p-3 rounded-lg text-center font-mono text-xs text-cyan-300">
            |0_L⟩ = |000⟩, &nbsp; |1_L⟩ = |111⟩
          </div>
          <p class="text-xs text-slate-400 leading-relaxed">
            We use <strong>ancilla qubits</strong> to perform <em>parity (syndrome) measurements</em> (e.g. measuring $Z_1 Z_2$ and $Z_2 Z_3$).
            The syndrome measurement tells us <em>which qubit flipped</em> without revealing whether the logical state was $|0\rangle$ or $|1\rangle$!
          </p>
        </div>
      </div>
    `
  }
];

if (typeof module !== 'undefined' && module.exports) {
  module.exports = CURRICULUM_DATA;
}
