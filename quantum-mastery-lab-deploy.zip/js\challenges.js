/**
 * Quantum Mastery Lab - Hands-On Circuit Challenges & Verification Engine
 * Automated verification checks quantum statevector fidelity, entanglement entropy,
 * and measurement statistics to validate user solutions.
 */

const CHALLENGES_DATA = [
  {
    id: "task-1",
    title: "1. Ignition: Superposition (|+)⟩",
    difficulty: "Beginner",
    diffColor: "emerald",
    numQubits: 1,
    description: "Prepare qubit 0 in the equal superposition state |+⟩ = (|0⟩ + |1⟩) / √2.",
    hint: "The Hadamard (H) gate maps computational basis state |0⟩ to |+⟩.",
    targetDirac: "(0.707)|0⟩ + (0.707)|1⟩",
    validator: (engine) => {
      const invSqrt2 = 1 / Math.SQRT2;
      const targetState = [new Complex(invSqrt2, 0), new Complex(invSqrt2, 0)];
      const fid = QuantumEngine.fidelity(engine.state, targetState);
      if (fid >= 0.99) {
        return { success: true, message: "Perfect! You created equal superposition with 50% probability of |0⟩ and 50% of |1⟩." };
      }
      return { success: false, message: `Fidelity is ${(fid * 100).toFixed(1)}%. Current state: ${engine.toDiracString(2)}` };
    }
  },
  {
    id: "task-2",
    title: "2. Relative Phase: Create (|i)⟩",
    difficulty: "Beginner",
    diffColor: "emerald",
    numQubits: 1,
    description: "Prepare qubit 0 in the complex phase state |i⟩ = (|0⟩ + i|1⟩) / √2.",
    hint: "First create |+⟩ using an H gate, then apply the S (Phase) gate to add a +90° relative phase (i) to |1⟩.",
    targetDirac: "(0.707)|0⟩ + (0.707i)|1⟩",
    validator: (engine) => {
      const invSqrt2 = 1 / Math.SQRT2;
      const targetState = [new Complex(invSqrt2, 0), new Complex(0, invSqrt2)];
      const fid = QuantumEngine.fidelity(engine.state, targetState);
      if (fid >= 0.99) {
        return { success: true, message: "Excellent! The state now points directly to the +Y axis on the Bloch sphere with a 90° relative phase." };
      }
      return { success: false, message: `Fidelity is ${(fid * 100).toFixed(1)}%. Current state: ${engine.toDiracString(2)}` };
    }
  },
  {
    id: "task-3",
    title: "3. Entanglement: Bell State (|Φ⁺)⟩",
    difficulty: "Intermediate",
    diffColor: "cyan",
    numQubits: 2,
    description: "Create the maximally entangled Bell pair |Φ⁺⟩ = (|00⟩ + |11⟩) / √2.",
    hint: "Apply an H gate on qubit 0 (control), then a CNOT gate with control=q0 and target=q1.",
    targetDirac: "(0.707)|00⟩ + (0.707)|11⟩",
    validator: (engine) => {
      const invSqrt2 = 1 / Math.SQRT2;
      const targetState = [
        new Complex(invSqrt2, 0),
        Complex.ZERO,
        Complex.ZERO,
        new Complex(invSqrt2, 0)
      ];
      const fid = QuantumEngine.fidelity(engine.state, targetState);
      const entropy = engine.getEntanglementEntropy();
      if (fid >= 0.99 && entropy >= 0.95) {
        return {
          success: true,
          message: "Outstanding! You constructed the canonical EPR Bell state. Entanglement entropy is 1.000 bit (maximum)!"
        };
      }
      return {
        success: false,
        message: `Fidelity is ${(fid * 100).toFixed(1)}%. Entanglement Entropy: ${entropy.toFixed(2)}.`
      };
    }
  },
  {
    id: "task-4",
    title: "4. The Singlet State (|Ψ⁻)⟩",
    difficulty: "Intermediate",
    diffColor: "cyan",
    numQubits: 2,
    description: "Create the antisymmetric Bell Singlet state |Ψ⁻⟩ = (|01⟩ - |10⟩) / √2.",
    hint: "Start with |11⟩ (toggle both initial states or use X gates), then apply H on q0 and CNOT(0, 1). Alternatively, apply X and Z gates after creating |Φ⁺⟩.",
    targetDirac: "(0.707)|01⟩ + (-0.707)|10⟩",
    validator: (engine) => {
      const invSqrt2 = 1 / Math.SQRT2;
      const targetState = [
        Complex.ZERO,
        new Complex(invSqrt2, 0),
        new Complex(-invSqrt2, 0),
        Complex.ZERO
      ];
      const fid = QuantumEngine.fidelity(engine.state, targetState);
      if (fid >= 0.99) {
        return {
          success: true,
          message: "Masterful! The Singlet state is completely invariant under simultaneous spatial rotations."
        };
      }
      return {
        success: false,
        message: `Fidelity is ${(fid * 100).toFixed(1)}%. Current state: ${engine.toDiracString(2)}`
      };
    }
  },
  {
    id: "task-5",
    title: "5. SWAP Synthesis (3 CNOTs)",
    difficulty: "Advanced",
    diffColor: "purple",
    numQubits: 2,
    description: "Synthesize a complete SWAP operation between q0 and q1 using exactly 3 CNOT gates (no native SWAP gate allowed).",
    hint: "Apply CNOT(q0, q1), then reverse direction with CNOT(q1, q0), then finish with CNOT(q0, q1)!",
    targetDirac: "State of q0 and q1 are exchanged",
    validator: (engine, circuit) => {
      // Check if user used 3 CNOTs alternating
      let cnots = [];
      for (let col of circuit.columns) {
        for (let g of col) {
          if (g.type === 'CX') cnots.push(g);
        }
      }
      if (cnots.length !== 3) {
        return { success: false, message: `Circuit must contain exactly 3 CNOT gates. Found ${cnots.length}.` };
      }
      const testEng = new QuantumEngine(2);
      testEng.resetState(2); // |10>
      for (let c of cnots) {
        testEng.applyGate(c.type, c.target, c.control);
      }
      // Target should now be |01> (index 1)
      if (testEng.state[1].absSq() >= 0.99) {
        return { success: true, message: "Brilliant! You verified the fundamental quantum identity: SWAP = CX(0,1) · CX(1,0) · CX(0,1)!" };
      }
      return { success: false, message: "The gates did not exchange the qubit states correctly. Check control and target orientations." };
    }
  },
  {
    id: "task-6",
    title: "6. Grover's 2-Qubit Search for |11⟩",
    difficulty: "Advanced",
    diffColor: "purple",
    numQubits: 2,
    description: "Construct the full 2-qubit Grover search circuit to amplify marked state |11⟩ to 100% measurement probability.",
    hint: "1. H on both qubits. 2. CZ oracle (flips phase of |11⟩). 3. Diffuser: H on both, X on both, CZ, X on both, H on both.",
    targetDirac: "(1.000)|11⟩",
    validator: (engine) => {
      const prob11 = engine.state[3].absSq();
      if (prob11 >= 0.95) {
        return {
          success: true,
          message: "Phenomenal! You successfully performed Grover Amplitude Amplification. |11⟩ has a ~100% probability of measurement!"
        };
      }
      return {
        success: false,
        message: `Probability of target |11⟩ is ${(prob11 * 100).toFixed(1)}% (requires ≥ 95%). Current state: ${engine.toDiracString(2)}`
      };
    }
  }
];

class ChallengeManager {
  constructor(circuitUiInstance) {
    this.circuitUI = circuitUiInstance;
    this.currentChallengeIndex = 0;
    this.completedTasks = new Set();
  }

  loadChallenge(index) {
    this.currentChallengeIndex = index;
    const task = CHALLENGES_DATA[index];
    this.circuitUI.setNumQubits(task.numQubits);
    this.circuitUI.clearCircuit();
    this.renderTaskCard();
  }

  verifyCurrent() {
    const task = CHALLENGES_DATA[this.currentChallengeIndex];
    // Run full circuit
    this.circuitUI.evaluateCircuit(this.circuitUI.numSteps - 1);
    const result = task.validator(this.circuitUI.engine, this.circuitUI);

    const feedbackEl = document.getElementById('task-feedback-box');
    if (!feedbackEl) return;

    if (result.success) {
      this.completedTasks.add(task.id);
      feedbackEl.className = 'p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 mt-4 transition-all duration-300';
      feedbackEl.innerHTML = `
        <div class="flex items-center space-x-2 font-bold text-sm">
          <span>🎉 Challenge Solved!</span>
        </div>
        <p class="text-xs text-slate-300 mt-1">${result.message}</p>
      `;
      this.updateProgressBadge();
    } else {
      feedbackEl.className = 'p-4 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-200 mt-4 transition-all duration-300';
      feedbackEl.innerHTML = `
        <div class="flex items-center space-x-2 font-bold text-sm">
          <span>⚠️ Not Quite Right</span>
        </div>
        <p class="text-xs text-slate-300 mt-1">${result.message}</p>
      `;
    }
  }

  updateProgressBadge() {
    const badgeEl = document.getElementById('tasks-completed-count');
    if (badgeEl) {
      badgeEl.textContent = `${this.completedTasks.size}/${CHALLENGES_DATA.length} Completed`;
    }
  }

  renderTaskCard() {
    const container = document.getElementById('challenge-container');
    if (!container) return;

    const task = CHALLENGES_DATA[this.currentChallengeIndex];
    const isCompleted = this.completedTasks.has(task.id);

    container.innerHTML = `
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div class="flex items-center justify-between mb-3">
          <div class="flex items-center space-x-2">
            <span class="px-2 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider bg-${task.diffColor}-500/20 text-${task.diffColor}-400 border border-${task.diffColor}-500/30">
              ${task.difficulty}
            </span>
            <span class="text-xs text-slate-400 font-mono">${task.numQubits} Qubit${task.numQubits > 1 ? 's' : ''}</span>
          </div>
          ${isCompleted ? '<span class="text-xs font-bold text-emerald-400">✓ Solved</span>' : ''}
        </div>

        <h3 class="text-base font-bold text-white mb-2">${task.title}</h3>
        <p class="text-xs text-slate-300 leading-relaxed mb-4">${task.description}</p>

        <div class="bg-slate-950/80 rounded-lg p-3 border border-slate-800 font-mono text-xs mb-4">
          <span class="text-slate-400 block text-[11px]">Target State:</span>
          <span class="text-cyan-300 font-bold">${task.targetDirac}</span>
        </div>

        <div class="flex flex-wrap gap-2">
          <button onclick="window.challengeManager.verifyCurrent()"
            class="px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold text-xs shadow-lg shadow-cyan-500/20 transition-all">
            ✓ Verify Solution
          </button>
          <button onclick="document.getElementById('task-hint-box').classList.toggle('hidden')"
            class="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700 transition-colors">
            💡 Show Hint
          </button>
          <button onclick="window.circuit.clearCircuit()"
            class="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs border border-slate-700 transition-colors">
            ↺ Reset
          </button>
        </div>

        <div id="task-hint-box" class="hidden mt-3 p-3 rounded-lg bg-amber-950/30 border border-amber-500/30 text-amber-200 text-xs">
          <strong>Hint:</strong> ${task.hint}
        </div>

        <div id="task-feedback-box"></div>
      </div>
    `;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { CHALLENGES_DATA, ChallengeManager };
}
