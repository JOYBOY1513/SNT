"""
Quantum State Visualizer
Generates publication-quality figures of quantum statevectors, phase distributions,
and Born rule measurement distributions using Matplotlib.
"""

import os
import matplotlib
matplotlib.use('Agg') # Headless rendering
import matplotlib.pyplot as plt
import numpy as np
from quantum_engine import QuantumCircuitSim, H, X

def generate_visualizations(output_path="quantum_visualizer_report.png"):
    # Create a 2-qubit Bell state |Phi+>
    sim = QuantumCircuitSim(2)
    sim.apply_1q_gate(H, 0)
    sim.apply_cnot(0, 1)

    probs = sim.get_probabilities()
    samples = sim.sample(1024)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5), facecolor='#090d16')

    labels = ['|00>', '|01>', '|10>', '|11>']
    colors = ['#38bdf8', '#818cf8', '#c084fc', '#f43f5e']

    # Subplot 1: Theoretical Probabilities
    ax1.set_facecolor('#0f172a')
    bars1 = ax1.bar(labels, probs, color='#38bdf8', edgecolor='#0284c7', width=0.55)
    ax1.set_title("Theoretical Probability Distribution |psi|^2", color='#f8fafc', fontsize=12, fontweight='bold', pad=12)
    ax1.set_ylabel("Probability", color='#94a3b8')
    ax1.set_ylim(0, 1.0)
    ax1.tick_params(colors='#94a3b8')
    ax1.grid(axis='y', linestyle='--', alpha=0.2, color='#94a3b8')

    for bar, p in zip(bars1, probs):
        if p > 0.01:
            ax1.text(bar.get_x() + bar.get_width()/2, p + 0.03, f"{p*100:.1f}%",
                     ha='center', va='bottom', color='#38bdf8', fontweight='bold', fontsize=10)

    # Subplot 2: 1024 Shots Simulated Measurement Histogram
    ax2.set_facecolor('#0f172a')
    sample_counts = [samples.get(format(i, '02b'), 0) for i in range(4)]
    bars2 = ax2.bar(labels, sample_counts, color='#a855f7', edgecolor='#7e22ce', width=0.55)
    ax2.set_title("Simulated Measurement Sampling (1024 Shots)", color='#f8fafc', fontsize=12, fontweight='bold', pad=12)
    ax2.set_ylabel("Measured Frequency (Shots)", color='#94a3b8')
    ax2.tick_params(colors='#94a3b8')
    ax2.grid(axis='y', linestyle='--', alpha=0.2, color='#94a3b8')

    for bar, c in zip(bars2, sample_counts):
        if c > 0:
            ax2.text(bar.get_x() + bar.get_width()/2, c + 15, f"{c}",
                     ha='center', va='bottom', color='#c084fc', fontweight='bold', fontsize=10)

    plt.tight_layout()
    fig.savefig(output_path, dpi=200, bbox_inches='tight')
    plt.close()
    print(f"[SUCCESS] Quantum visualization report saved to: {output_path}")

if __name__ == "__main__":
    generate_visualizations()
